*** Settings ***
Library     SeleniumLibrary
Library    String
Library    DateTime
Library    Collections
Resource    ../Pages/global_variable.robot
Resource    ../Pages/LoginPage.robot
Resource    ../Pages/HomePage.robot
Resource    ../Pages/InboxPage.robot
Resource    ../Pages/InvoiceTranscationDetailPage.robot


*** Variables ***
${LOGIN URL}        https://finato-uat.i-processmanager.com/IPMV4/Login/
${BROWSER}      Chrome
${Feild_LoginContinue}           //*[@id="authenticate"]/div/div/div
${CheckBox_Continue_Login}      //*[@id="choice1"]
${button_Submit_Continue}       //*[@id="btnSubmit"]


#Date picker variables
${Button_Date_Incorporation}     //span[@aria-controls="dtpicker_FileSaveDate_Of_Incorporation_dateview"]
${Button_Dt_Header_MonthYear}       //a[@class="k-link k-nav-fast"]
${Button_Dt_Header_MonthYear2}   //a[@class="k-link k-nav-fast k-state-hover"]
${Button_Dt_Left_Arrow}     //a[@aria-label="Previous"]
${Button_Dt_YearRange}       //div[@class='k-calendar-view']//a

#Date Picker
${year_range_Button}        //a[@class="k-link k-nav-fast k-state-hover"]
${Button_Dt_Left_Arrow}     //a[@aria-label="Previous"]
${Button_Dt_YearRange}       //div[@class='k-calendar-view']//a
${Button_Dt_Header_MonthYear}       //a[@class="k-link k-nav-fast"]
${Button_Dt_Header_MonthYear2}   //a[@class="k-link k-nav-fast k-state-hover"]
${Button_Dt_Left_Arrow}     //a[@aria-label="Previous"]
${Button_Dt_YearRange}       //div[@class='k-calendar-view']//a


${TOAST_MESSAGE}               # This is a retrived toast message

*** Keywords ***
#selects dropdown option based on passed argument
Open Browser To Login Page
    Open Browser    ${LOGIN URL}    ${BROWSER}
    Maximize Browser Window
    Sleep    10s
    Wait Until Page Contains Element    id=login
    Click Continue Login

Click Continue Login
  Run Keyword And Ignore Error   Wait Until Element Is Visible    ${Feild_LoginContinue}     timeout=05s      error=False
     ${ContinueLogin}=  Is Element Visible  ${Feild_LoginContinue}
               IF    $ContinueLogin==True
                    Click Element   ${CheckBox_Continue_Login}
                    Click Element   ${button_Submit_Continue}

               END
Is Element Visible
    [Documentation]   Checks and Returns Boolean value
    ...    ex. ${result}=Is Element Visible     ${Locator}
    ...     returns True | False

    [Arguments]     ${Element}
     ${result}=     Run Keyword And Return Status    Element Should Be Visible  ${Element}   05s
     RETURN     ${result}




Select Dropdown by Value
    [Documentation]     Opens the dropdown and select the option ex. Select Dropdown by Value ${xpathofdropdwon}    Incora

    [Arguments]     ${DropDownLocator}   ${dropdownValue}
    ${Setoption}=    Set Variable   //li[text()='${dropdownValue}'] | //span[text()='${dropdownValue}']
    Wait Until Element Is Visible    ${DropdownLocator}     5s
    Wait for Element and Click      ${DropdownLocator}
    Wait for Element and Click  ${Setoption}

#Clicks when element is ready to be clickable
Wait for Element and Click
    [Arguments]    ${locator}
    Wait Until Element Is Visible    ${locator}     10s
    Click Element    ${locator}

Input text and select option from suggestion box
    [Documentation]     Inputs texts and select the first option that appears for the entered text
    ...  Ex. Wait for Element and Select Option      ${INPUT_currencyXpath}  INR   ${XpathOfOption}

    [Arguments]     ${locator}   ${text}    ${locator_select}
    Wait Until Element Is Visible    ${locator}     5s
    Scroll Element Into View     ${locator}
    Input Text    ${locator}    ${text}
    Wait for Element and Click    ${locator_select}

Wait for element visible and input text

    [Arguments]    ${locator}   ${text}
    Wait Until Element Is Visible    ${locator}     10s
    Input Text    ${locator}     ${text}
Wait for Element and Input
    [Documentation]    Clears text and input given parameter
    [Arguments]     ${locator}   ${text}
    Wait for Element to Enable   ${locator}
    Scroll Element Into View     ${locator}
    ${current_value}    Get Element Attribute    ${locator}    value
     IF    '${current_value}' != ''
        Clear Element Text   ${locator}
         Sleep    2s
    END
    Input Text    ${locator}    ${text}     log=False

Wait for Element to Enable
    [Arguments]   ${locator}
    Wait Until Element Is Visible    ${locator}     5s
    Wait Until Element Is Enabled    ${locator}     10s




Scroll into View
    [Documentation]  Powerful keyword to Scrolls the element by JS
    [Arguments]     ${locator}
    Wait for Element to Enable    ${locator}
    Execute JavaScript   window.document.evaluate("${locator}", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.scrollIntoView(true);


Scroll Until Element Is Visible
    [Arguments]    ${element_locator}    ${max_scroll_attempts}=10
    ${is_visible}=    Run Keyword And Return Status    Element Should Be Visible    ${element_locator}
    FOR    ${index}    IN RANGE    ${max_scroll_attempts}
        Exit For Loop If    ${is_visible} == True
        Execute JavaScript    window.scrollBy(0, 200)  # Scroll down by 200 pixels
        Sleep    1s  # Allow time for dynamic content to load
        ${is_visible}=    Run Keyword And Return Status    Element Should Be Visible    ${element_locator}
    END
    IF    ${is_visible} == False
        Fail    Element '${element_locator}' not visible after ${max_scroll_attempts} scroll attempts.
    END

Date Picker
    [Documentation]  Selects dates if given in this format: MM/DD/YYYY
            ...     for ex:     Date Picker  Feb/15/2000
    [Arguments]       ${DateElement}     ${GetDate}
    #Extract Date Value
    ${Set_Date}=    Set Variable   ${GetDate}
    ${Below1990}=   Convert To Integer    1990

    #Splits the given string  and Set to each variables
    @{date_parts}=   Split String    ${Set_Date}     /
    ${month}=       Set Variable    ${date_parts}[0]
#    ${day}=         Convert To Integer    ${date_parts}[1]
    ${year}=        Convert To Integer   ${date_parts}[2]

     # Convert month name to UI month index
    ${month_dict}    Create Dictionary    Jan=0    Feb=1    Mar=2    Apr=3    May=4    Jun=5    Jul=6    Aug=7    Sep=8    Oct=9    Nov=10    Dec=11
    ${monthnumber}    Get From Dictionary    ${month_dict}    ${month}

     ${Get_User_Month}=  Set Variable   //a[normalize-space()='${date_parts}[0]']
    # ${Get_Day}=   Set Variable   //a[normalize-space()='${date_parts}[1]']
     ${Get_User_Year}=   Set Variable   //a[normalize-space()='${date_parts}[2]']
     ${Get_User_Day}=   Set Variable   //a[@data-value='${date_parts}[2]/${monthnumber}/${date_parts}[1]']


    #Get and Extract Current Date
    ${current_date}=    Get Current Date
    ${formatted_date}=    Convert Date    ${current_date}    result_format=%b/%d/%Y
    @{extract_current_date}=   Split String    ${formatted_date}     /
#    ${cur_month}=       Set Variable    ${extract_current_date}[0]
#    ${cur_day}=         Set Variable    ${extract_current_date}[1]
    ${cur_year}=        Convert To Integer   ${extract_current_date}[2]

    Wait for Element and Click      ${DateElement}

    #If user defined year is same as current year
    IF  '${year}'=='${cur_year}'
          Log To Console    Inside IF  loop  as year is same        level=info
         Wait for Element and Click    ${Button_Dt_Header_MonthYear}
         Wait for Element and Click      ${Get_User_Month}
         Wait for Element and Click      ${Get_User_Day}
    ELSE IF    $year < $Below1990
           Log To Console    Inside Else IF loop
          Wait for Element and Click    ${Button_Dt_Header_MonthYear}
           Wait for Element and Click   ${Button_Dt_Header_MonthYear2}
           Wait for Element to Enable    ${Button_Dt_Header_MonthYear2}
           Wait for Element and Click    ${Button_Dt_Header_MonthYear2}
           Wait for Element to Enable    ${Button_Dt_Left_Arrow}
           Wait for Element and Click     ${Button_Dt_Left_Arrow}
           Wait for Element to Enable    ${Button_Dt_YearRange}

            ${elements}=    Get WebElements    ${Button_Dt_YearRange}

            #Go through each retrieved text
         FOR    ${element}    IN    @{elements}
            ${Get_Year_range}=    Get Text    ${element}
            #split the retrieved text into start and end year var
             IF     '${Get_Year_range}' != ''
                ${start_year}=    Set Variable    ${Get_Year_range.split('-')[0].strip()}  # Extract start year
                ${end_year}=    Set Variable    ${Get_Year_range.split('-')[1].strip()}    # Extract end year
               #compare if user defined year is within the range of start 'AND' end year
               IF  ${start_year} <= ${year} <= ${end_year}
                     #if match found set the  year range value to locator
                     ${Year_Range}=     Set Variable     //a[normalize-space()='${Get_Year_range}']
                     #click on year range
                     Wait for Element and Click    ${Year_Range}
                     Wait for Element and Click   ${Get_User_Year}
                     Wait for Element and Click      ${Get_User_Month}
                    Wait for Element and Click   ${Get_User_Day}
                    Exit For Loop
               END
             END
         END
    ELSE
           Log To Console    Inside Else loop
           Wait for Element and Click    ${Button_Dt_Header_MonthYear}
           Wait for Element and Click   ${Button_Dt_Header_MonthYear2}
           Wait for Element to Enable    ${Button_Dt_Header_MonthYear2}
           Wait for Element and Click    ${Button_Dt_Header_MonthYear2}

           #retrieves values from main date  year ranges
           ${elements}=    Get WebElements     ${Button_Dt_YearRange}

            #Go through each retrieved text
         FOR    ${element}    IN    @{elements}
            ${Get_Year_range}=    Get Text    ${element}
            #IF the retreived value is empty then skip
             IF     '${Get_Year_range}' != ''
            #split the retrieved text into start and end year var

            ${start_year}=    Set Variable    ${Get_Year_range.split('-')[0].strip()}  # Extract start year
            ${end_year}=    Set Variable    ${Get_Year_range.split('-')[1].strip()}    # Extract end year
            #compare if user defined year is within the range of start 'AND' end year
               IF  ${start_year} <= ${year} <= ${end_year}
                     #if match found set the  year range value to locator
                     ${Year_Range}=     Set Variable     //a[normalize-space()='${Get_Year_range}']
                     #click on year range
                     Wait for Element and Click    ${Year_Range}
                     Wait for Element and Click   ${Get_User_Year}
                     Wait for Element and Click      ${Get_User_Month}
                     Sleep    2s
                    Wait for Element and Click   ${Get_User_Day}
                    Exit For Loop
               END
            END
         END
    END

Retrieve IRN and Store into Variable
    [Documentation]  Fetches the integer from the field and stores it globally

    # Wait for the field to be visible/ready
    Wait Until Element Is Visible    //input[@id="FileSavedrn"]    timeout=10s

    # Get the value (as a string)
    ${value_str}=    Get Element Attribute    //input[@id="FileSavedrn"]    value

    # Convert to integer (if needed for numeric operations)
    ${value_int}=    Convert To Integer    ${value_str}

    # Store globally (accessible everywhere)
    Set Global Variable    ${Current_IRN}    ${value_int}



Retrieve Toast Message
    [Documentation]  Gets text from the er




    ror toast notification

    # Wait for toast to appear
    Wait Until Element Is Visible    //small[@id="toast_msg"]    10s

    # Get the error message text
    ${error_text}=    Get Text    //small[@id="toast_msg"]

    # Store in variable (global for cross-keyword access)
    Set Global Variable    ${TOAST_MESSAGE}    ${error_text}

    # Optional: Log or validate
    Log To Console    Toast Error: ${TOAST_MESSAGE}
    [Return]    ${error_text}


