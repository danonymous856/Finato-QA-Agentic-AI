*** Variables ***
${IRN}                      //input[@id='txtdrn']
${Vendor_Name}              //input[@id='txtVendor_Name']
${Vendor_Code}              //input[@id='txtVendor_Code']
${Invoice_Number}           //input[@id='txtInvoiceNumber']

${value}                    567
${Invalid_IRN_Value}        88993
${Vendor_Name_Value}        Hapag
${Invalid_Vendor_Name_Value}    Test123
${Vendor_Code_Value}        2197
${Invalid_Vendor_Code_Value}    0989376
${Invoice_Number_Value}     24-08424
${Invalid_Invoice_Number_Value}     Test-12345
${SUBMIT_BUTTON}            //input[@id='Primary']
#${Warning_MSG} denotes the invalid parameter output
${Warning_MSG}              //div[@class="k-grid-norecords-template"]
# Validation locators for redirection and error messages
${Actual_IRN}           xpath=//a[text()='${value}']  #from this we can retrieve data of actual IRN data
${Actual_Vendor_Name}   xpath=//tr[@class="k-state-selected"]//td[@role="gridcell"][normalize-space()='${Vendor_Name_Value}']  #from this we can retrieve data of actual Vendor name data
${Actual_Vendor_Code}   xpath=//tr[@class="k-state-selected"]//td[@role="gridcell"][normalize-space()='${Vendor_Code_Value}']  #from this we can retrieve data of actual Vendor code data
${Actual_Invoice_Number}    xpath=//td[@data-field="InvoiceNumber" and text()="${Invoice_Number_Value}"]  #from this we can retrieve data of actual Invoice number
