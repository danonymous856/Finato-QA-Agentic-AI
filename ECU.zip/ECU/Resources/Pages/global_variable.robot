*** Variables ***
${LOGIN URL}        https://finato-uat.i-processmanager.com/IPMV4/Login/
#${LOGIN URL}        https://dev.i-processmanager.com/IPMV4/Login/Index
${BROWSER}          Chrome


# Sucess or error messages
${Current_IRN}
${SUCCESS_MSG_PATTERN}         Transaction ${Current_IRN} saved successfully
${AMOUNT_MISMATCH_ERROR}       M010-Sum Of Invoice Line Amount(HC) and Invoice Header Amount should be same. Difference is exceeding the tolerance 0.1
${Toast_MSG}                   //small[@id="toast_msg"]/ancestor::div[@class="toast-header toast-success text-xs"]
${TOAST_MESSAGE}               # This is a retrived toast message

${excelFilepath}                ${EXECDIR}/Resources/MatchingTestData.xlsx



