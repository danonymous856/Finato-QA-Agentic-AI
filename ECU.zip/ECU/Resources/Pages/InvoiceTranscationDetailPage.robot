*** Variables ***
#Invoice processing transaction detail page Header Line item
${Current_IRN}
${Currency_Value}               GBP

${InvoiceNumber}                //input[@id="FileSaveInvoiceNumber"]
${invoiceAmount}                //input[@id="FileSaveInvoiceAmount"]/preceding-sibling::input
${invoiceDate}                  //span[@aria-controls="dtpicker_FileSaveInvoiceDate_dateview"]
${Invoice_ref_number}           //input[@id="FileSaveInvoice_Reference_number"]
${ExchangeRate_Sibling}         //input[@id="FileSaveExchange_Rate"]/preceding-sibling::input
${ExchangeRate}                 //input[@id="FileSaveExchange_Rate"]
${ExchangeRateError}            //span[@id="FileSaveExchange_Rate-error"]

${Submit}                       //input[@id="Update2"]

${XPATH_INVOICE_TOTAL}          //input[@id='FileSaveInvoiceAmount']
${InvoiceAmount_INPUT_FIELD}    //input[@id="FileSaveInvoiceAmount"]
${VISIBLE_INPUT}                //input[contains(@class, 'k-formatted-value')]
${NUMERIC_WRAP}                 //span[contains(@class, 'k-numeric-wrap')]
${VAT_Field_Sibling}            //input[@id="FileSaveVATAmount"]/preceding-sibling::input
${VAT_Field}                    //input[@id="FileSaveVATAmount"]
${Currency_Suggesionbox}        //input[@aria-labelledby="FileSaveCurrency_label"]
${Select_Currency}              //span[text()='${Currency_Value}']




# used for select activity
${activity name}                (//label[contains(@class,'txt1 col-form-label-sm')])[22]
${Activity_Code_Dropdown}       //select[@id="Activity_Code"]/ancestor::span[contains(@class, 'k-dropdown')]
${Dropdown_Arrow}               ${Activity_Code_Dropdown}//span[contains(@class, 'k-i-arrow-60-down')]
${Dropdown_Options}             //ul[@id="Activity_Code_listbox"]/li


#Add Invoice line Item frame
${IsCheckBox_Present}           (//table[@tabindex="0"]//tbody[1]//tr[1])[1]
${ActionCheckBox}               //input[@id="header-chb"]
${deleteButton}                 //a[@id="DeleteTransaction"]
${ConfirmDeletePopup}           //a[normalize-space()="Confirm to continue?"]
${Add_Button}                   //a[@id="AddTransaction"]
${Sequence Number}              //input[@id="FileSaveBlSeq"]
${Container Number}             //input[@id="FileSaveContainer_Number"]
${Booking Number}               //input[@id="FileSaveBooking_Number"]
${BL Number}                    //input[@id="FileSaveBL_Number"]
${Ocean BL Number}              //input[@id="FileSaveOceanBL"]
${File Number}                  //input[@id="FileSaveFile_Number"]
${Truck Number}                 //input[@id="FileSaveTruck_Number"]
${Item Description}             //input[@id="FileSaveItem_Description"]
${Currency}                     (//input[@aria-owns="FileSaveCurrency_listbox"])[1]
${suggestionbox}                //span[text()='GBP']
${Quantity}                     (//input[@class="k-formatted-value IsNumbersWithDecimal k-input"])[1]
${Unit Price}                   /html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[13]/div[2]/span[1]/span[1]/input[1]
${Unit Price Visible}           xpath=//input[contains(@class, 'k-formatted-value') and not(contains(@style, 'display: none'))]
${Line Amount without VAT}
${Rate}                         (//input[contains(@class,'IsNumbersWithDecimal') and  not (contains(@style,'display: none'))])[4]
${VAT Tax Percentage}           (//input[contains(@class,'IsNumbersWithDecimal') and  not (contains(@style,'display: none'))])[5]
${VAT Tax Amount}
${Line Amount with VAT}
${Amount(HC)}                   (//input[contains(@class,'IsNumbersWithDecimal') and  not (contains(@style,'display: none'))])[8]
#${scroll}                      //label[text()='Line Amount without VAT']
${Save_Button}                  //input[@id='UpdateLineItem2']
${XPATH_TOTAL_AMOUNT HC}        (//div[contains(text(), 'Sum:')])[5]
