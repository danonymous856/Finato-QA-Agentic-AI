*** Variables ***
#hompage locators
${QC_REVIEW_LOCAL_COUNT}        //tr[4]/td[4]/a
${country_dropdown}            (//span[@class='k-icon k-i-arrow-60-down'])[1]
${country_Search_option}       //input[@aria-owns='selectPlant_listbox']
${Country_Name}             UNITED KINGDOM
${Select_Country}      //ul[@id='selectPlant_listbox']/li[text()='UNITED KINGDOM']


