*** Variables ***
#Inbox page locators
${IRN_Filter}       //tr[1]/th[3]/a[text()='IRN']
${Recent_IRN}       //body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/a
