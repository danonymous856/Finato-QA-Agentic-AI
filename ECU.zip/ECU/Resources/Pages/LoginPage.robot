*** Variables ***
${VALID USERNAME}         ECU_Auditor1
${VALID PASSWORD}         Sysadmin@123
${username_field}         //input[@id="User_Name"]
${password_field}         //input[@id="User_Password"]
${loginbtn}               //input[@id="login"]


#pop up screen
${Feild_LoginContinue}           //*[@id="authenticate"]/div/div/div
${CheckBox_Continue_Login}      //*[@id="choice1"]
${button_Submit_Continue}       //*[@id="btnSubmit"]