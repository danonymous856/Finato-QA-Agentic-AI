# utils/json_exporter.py

import json
import sys
import os
from datetime import datetime
from openpyxl import Workbook
import csv

def save_json_to_excel(json_string, output_dir="logs_excel"):
    os.makedirs(output_dir, exist_ok=True)
    data = json.loads(json_string)
    now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_path = os.path.join(output_dir, f"irn_log_{now}.xlsx")

    wb = Workbook()
    ws = wb.active
    ws.title = "IRN Logs"

    if not data:
        raise ValueError("No data provided")

    headers = list(data[0].keys())
    ws.append(headers)

    for entry in data:
        ws.append([entry.get(h, "") for h in headers])

    wb.save(file_path)
    return file_path  # ✅ Return the path instead of just printing it


def save_json_to_csv(json_string, output_dir="logs_csv"):
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Parse JSON string to Python object
    data = json.loads(json_string)

    # Generate filename with timestamp
    now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_path = os.path.join(output_dir, f"irn_log_{now}.csv")

    # Check if data exists
    if not data:
        raise ValueError("No data provided")

    # Get headers from first entry
    headers = list(data[0].keys())

    # Write to CSV
    with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=headers)
        writer.writeheader()
        writer.writerows(data)

    return file_path

if __name__ == "__main__":
    # For CLI usage
    input_json = sys.stdin.read()
    # save_json_to_excel(input_json)
    save_json_to_csv(input_json)