*** Settings ***
Library           SeleniumLibrary
Library           Collections
Library           OperatingSystem
Library           String
Library           RPA.Excel.Files
Library           BuiltIn
Library           Process
Library           CustomKeywords.py
Library           json_to_excel.py
Resource          ../../Resources/Pages/InboxPage.robot
Resource          ../../Resources/Pages/LoginPage.robot
Resource          ../../Resources/Pages/HomePage.robot
Resource          ../../Resources/Keywords/Global_Keywords.robot
Resource          ../Regression_Suite/karan_working/test .robot
Variables         ../../Resources/Pages/global_variable.robot
Suite Setup       Open Browser To Login Page
Suite Teardown    Close Browser

*** Variables ***
${EXCEL_PATH}                ./irn_results.xlsx
${Activity_Name}             QC Review
${Country_Name}              UNITED KINGDOM
${IRN_Filter}                //th[@data-title='IRN']//a[contains(@class, 'k-link')]
${Submit}                    //input[@id="Update2"]
${VALID USERNAME}            ECU_resolver1
${VALID PASSWORD}            Sysadmin@123
${count}                     3
@{results}                   # List to accumulate all IRN submission results

*** Test Cases ***
Submit Top N IRNs From Inbox
    Enter Login Credentials
    Navigate To Inbox Page
    ${start_time}=    Get Time    epoch
    ${end}=    Evaluate    int(${count}) + 1
    FOR    ${index}    IN RANGE    1    ${end}
        Reload Inbox
        Filter Activity And Country
        Click On IRN Filter To Get Latest IRN    ${index}
        ${irn}=    Get Latest IRN    ${index}
        Open IRN Page    ${irn}
        Select Activity Dropdown
        Submit button
        ${status}=    Run Keyword And Return Status    Wait Until Element Contains    id=statusMessage    Submitted    timeout=5s
        ${activity}=    Get Value    id=txtActivity_Code
        IF    ${status}
            ${message}=    Set Variable    Transaction Success
        ELSE
            ${result_tuple}=    Run Keyword And Ignore Error    Get Text    xpath=//ul[contains(@class,"un-oder")]
            ${error_type}=      Set Variable    ${result_tuple}[0]
            ${message}=         Set Variable    ${result_tuple}[1]
            IF    '${error_type}' == 'FAIL'
                ${message}=    Set Variable    Transaction Success
            END
        END
        ${result}=    Create Dictionary    IRN=${irn}    Status=${activity}    Message=${message}
        Get Data in JSON    ${result}
        Close IRN Detail Page
    END
    ${end_time}=    Get Time    epoch
    ${duration}=    Evaluate    round(${end_time} - ${start_time}, 2)
    ${json_data}=   Print Final JSON Results
    Log To Console    \n Time taken to process ${count} IRNs: ${duration} seconds

#    JSON to Excel File    ${json_data}
    JSON to CSV File      ${json_data}

*** Keywords ***
Enter Login Credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}    ${VALID USERNAME}
    Input Text    ${password_field}    ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    xpath=//h1[text()='Activity Matrix']    timeout=10s

Navigate To Inbox Page
    Click Element    xpath=//a[.//span[text()='Inbox']]
    Wait Until Element Is Visible    xpath=//a[.//span[text()='Inbox']]    timeout=10s
    Sleep    2s

Reload Inbox
    Go To    https://finato-uat.i-processmanager.com/IPMV4/Plugin/Inbox
    Wait Until Page Contains    Inbox    timeout=15s

Filter Activity And Country
    Execute JavaScript    document.getElementById("selectActivityCode").style.display = 'block'
    Select From List By Label    id=selectActivityCode    ${Activity_Name}
    Sleep    2s
    Execute JavaScript    document.getElementById("selectPlant").style.display = 'block'
    Select From List By Label    id=selectPlant    ${Country_Name}
    Sleep    2s

Click On IRN Filter To Get Latest IRN
    [Arguments]    ${index}
    Wait Until Element Is Visible    ${IRN_Filter}    timeout=10s
    Click Element    ${IRN_Filter}
    Sleep    3s
    ${refilter}=    Get WebElement    ${IRN_Filter}
    Click Element    ${refilter}
    Sleep    2s
    ${refilter}=    Get WebElement    ${IRN_Filter}
    Click Element    ${refilter}
    Sleep    2s
    ${dynamic_xpath}=    Set Variable    //tbody/tr[${index}]/td[3]/a
    Wait Until Element Is Visible    xpath=${dynamic_xpath}    timeout=10s

Get Latest IRN
    [Arguments]    ${index}
    ${dynamic_xpath}=    Set Variable    //tbody/tr[${index}]/td[3]/a
    ${irn}=    Get Text    xpath=${dynamic_xpath}
    RETURN    ${irn}

Open IRN Page
    [Arguments]    ${irn}
    Click Element    xpath=//a[text()='${irn}']
    Wait Until Page Contains Element    id=Update2    timeout=15s

Select Activity Dropdown
    Scroll Element Into View    id=Activity_Code_label
    Wait Until Element Is Not Visible    //div[@class='transaction-modal-footer']    timeout=10s
    ${Dropdown_Arrow}=    Set Variable    //label[@id='Activity_Code_label']/following::span[contains(@class,'k-dropdown-wrap')][1]
    Wait Until Element Is Visible    ${Dropdown_Arrow}    timeout=10s
    Execute JavaScript    document.evaluate(`${Dropdown_Arrow}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()
    Sleep    0.5s
    Wait Until Element Is Visible    //ul[@id="Activity_Code_listbox"]//li[normalize-space()='Send For Match']    timeout=10s
    Click Element    //ul[@id="Activity_Code_listbox"]//li[normalize-space()='Send For Match']

Submit button
    Click Element    ${Submit}
    Sleep    2s

Close IRN Detail Page
    Click Element    id=RedirectonClose2
    Sleep    2s

Get Data in JSON
    [Arguments]    ${entry}
    Append To List    ${results}    ${entry}

Print Final JSON Results
    ${json_data}=    Evaluate    json.dumps(${results}, indent=2)    json
    Log To Console    \n========= Final IRN Submission Results =========\n${json_data}
    RETURN    ${json_data}

JSON to Excel File
    [Arguments]    ${json_string}
    ${file_path}=    Evaluate    __import__('json_to_excel').save_json_to_excel(r'''${json_string}''')    json_to_excel
    Log To Console    Excel file saved at: ${file_path}

JSON to CSV File
    [Arguments]    ${json_string}
    ${file_path}=    Evaluate    __import__('json_to_excel').save_json_to_csv(r'''${json_string}''')    json_to_excel
    Log To Console    CSV file saved at: ${file_path}