*** Settings ***
Library             SeleniumLibrary
Resource         ../../Resources/Keywords/Global_Keywords.robot
Resource         ../../Resources/Pages/LoginPage.robot
Resource         ../../Resources/Pages/HomePage.robot
Resource     ../../Resources/Pages/SearchPage.robot
Force Tags       Regression


Suite Setup         Open Browser To Login Page
Test Template       Validate Filter Field with Redirect and Error Check

*** Test Cases ***         Locator                  value
IRN                        ${IRN}                   ${value}
Invalid IRN                ${IRN}                   ${Invalid_IRN_Value}
Vendor_Name                ${Vendor_Name}           ${Vendor_Name_Value}
Invalid Vendor_Name        ${Vendor_Name}           ${Invalid_Vendor_Name_Value}
Vendor_Code                ${Vendor_Code}           ${Vendor_Code_Value}
Invalid Vendor_Code        ${Vendor_Code}           ${Invalid_Vendor_Code_Value}
Invoice_Number             ${Invoice_Number}        ${Invoice_Number_Value}
Invalid Invoice_Number     ${Invoice_Number}        ${Invalid_Invoice_Number_Value}

*** Keywords ***
Open Browser To Login Page
    Open Browser    ${LOGIN URL}    ${BROWSER}
    Maximize Browser Window
    Wait Until Page Contains Element    id=login
    Login
    Click Continue Login
    Navigate to Filter page

Click Continue Login
    Run Keyword And Ignore Error   Wait Until Element Is Visible    ${Feild_LoginContinue}     timeout=05s      error=False
    ${ContinueLogin}=  Is Element Visible  ${Feild_LoginContinue}
    IF    $ContinueLogin==True
        Click Element   ${CheckBox_Continue_Login}
        Click Element   ${button_Submit_Continue}
    END

Is Element Visible
    [Documentation]   Checks and Returns Boolean value
    ...    ex. ${result}=Is Element Visible     ${Locator}
    ...     returns True | False
    [Arguments]     ${Element}
    ${result}=     Run Keyword And Return Status    Element Should Be Visible  ${Element}   05s
    RETURN     ${result}

Login
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}   ${VALID USERNAME}
    Input Text    ${password_field}   ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']  timeout=10s

Navigate to Filter page
    Click Element    //span[@title='Search']
    Wait Until Page Contains Element    xpath=//h6[text()='Filter']   timeout=10s

Validate Filter Field with Redirect and Error Check
    [Arguments]    ${field_locator}    ${input_value}
    Wait Until Element Is Visible    ${field_locator}    timeout=5s
    Input Text    ${field_locator}    ${input_value}
    Click Element    ${SUBMIT_BUTTON}

    # Validate IRN
    IF    '$field_locator' == '$IRN'
        Validate Redirect Page    ${input_value}    ${EMPTY}    ${EMPTY}    ${EMPTY}
    END

    # Validate Vendor Name
    IF    '$field_locator' == '$Vendor_Name'
        Wait Until Element Is Visible    ${Vendor_Name}    timeout=10s
        Validate Redirect Page    ${EMPTY}    ${input_value}    ${EMPTY}    ${EMPTY}
    END

    # Validate Vendor Code
    IF    '$field_locator' == '$Vendor_Code'
        Wait Until Element Is Visible    ${Vendor_Code}    timeout=10s
        Validate Redirect Page    ${EMPTY}    ${EMPTY}    ${input_value}    ${EMPTY}
    END

    # Validate Invoice Number
    IF    '$field_locator' == '$Invoice_Number'
        Wait Until Element Is Visible    ${Invoice_Number}    timeout=10s
        Validate Redirect Page    ${EMPTY}    ${EMPTY}    ${EMPTY}    ${input_value}
    END

    Return to Filter Page

Validate Redirect Page
    [Documentation]     Validate contents on the redirected page.
    [Arguments]    ${input_value}    ${vendor_name_value}    ${vendor_code_value}    ${invoice_number_value}

    # Validate IRN if input_value is provided
    IF    '${input_value}' != '${EMPTY}'
        ${GET_IRN_TEXT}=   Set Variable    xpath=//a[text()='${input_value}']
        Log    Checking IRN: ${GET_IRN_TEXT}
        Wait Until Page Contains Element    ${GET_IRN_TEXT}    timeout=20s
        Log    IRN validation passed.
    END

    # Validate Vendor Name if vendor_name_value is provided
    IF    '${vendor_name_value}' != '${EMPTY}'
        ${GET_VENDOR_TEXT}=   Set Variable    xpath=//tr[@class="k-state-selected"]//td[@role="gridcell"][normalize-space()='${vendor_name_value}']
        Log    Checking Vendor Name: ${GET_VENDOR_TEXT}
        Wait Until Page Contains Element    ${GET_VENDOR_TEXT}    timeout=20s
        Log    Vendor name validation passed.
    END

    # Validate Vendor Code if vendor_code_value is provided
    IF    '${vendor_code_value}' != '${EMPTY}'
        ${GET_VENDOR_CODE_TEXT}=   Set Variable    xpath=//tr[@class="k-state-selected"]//td[@role="gridcell"][normalize-space()='${vendor_code_value}']
        Log    Checking Vendor Code: ${GET_VENDOR_CODE_TEXT}
        Wait Until Page Contains Element    ${GET_VENDOR_CODE_TEXT}    timeout=20s
        Log    Vendor code validation passed.
    END

    # Validate Invoice Number if invoice_number_value is provided
    IF    '${invoice_number_value}' != '${EMPTY}'
        ${GET_INVOICE_NUMBER_TEXT}=   Set Variable    xpath=//td[@data-field="InvoiceNumber" and text()="${invoice_number_value}"]
        Log    Checking Invoice Number: ${GET_INVOICE_NUMBER_TEXT}
        Wait Until Page Contains Element    ${GET_INVOICE_NUMBER_TEXT}    timeout=20s
        Log    Invoice number validation passed.
    END

    # Capture Page Screenshot (optional)
    # Capture Page Screenshot    redirected-${input_value}-${vendor_name_value}-${vendor_code_value}-${invoice_number_value}.png

Return to Filter Page
    [Documentation]     Navigate back to the filter page.
    Navigate to Filter page
    Wait Until Page Contains Element    xpath=//h6[text()='Filter']   timeout=10s
    Log    Returned to filter page.

Validate Invalid Filter Field
    [Arguments]    ${field_locator}    ${input_value}
    Wait Until Element Is Visible    ${field_locator}    timeout=5s
    Input Text    ${field_locator}    ${input_value}
    Click Element    ${SUBMIT_BUTTON}
    Verify No Records Available

Verify No Records Available
    [Documentation]    Verify that the "No records available" message is displayed.
    Wait Until Element Is Visible    ${Warning_MSG}    timeout=10s
    Element Text Should Be    ${Warning_MSG}    No records available