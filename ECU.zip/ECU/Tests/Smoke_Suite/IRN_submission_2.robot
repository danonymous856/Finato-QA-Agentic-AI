*** Settings ***
Library           SeleniumLibrary
Library           Collections
Library           OperatingSystem
Library           String
Library           RPA.Excel.Files
Library           BuiltIn
Library           CustomKeywords.py
Resource          ../../Resources/Pages/InboxPage.robot
Resource          ../../Resources/Pages/LoginPage.robot
Resource          ../../Resources/Pages/HomePage.robot
Resource          ../../Resources/Keywords/Global_Keywords.robot
Resource          ../Regression_Suite/karan_working/test .robot
Variables         ../../Resources/Pages/global_variable.robot
Suite Setup       Open Browser To Login Page
Suite Teardown    Close Browser

*** Variables ***
${EXCEL_PATH}                ./irn_results.xlsx
${Activity_Name}             QC Review
${Country_Name}              UNITED KINGDOM
${IRN_Filter}                //th[@data-title='IRN']//a[contains(@class, 'k-link')]
${Recent_IRN}                //tbody/tr[1]/td[3]/a
${Submit}                    //input[@id="Update2"]
${VALID USERNAME}            ECU_resolver1
${VALID PASSWORD}            Sysadmin@123

*** Test Cases ***
Submit One IRN
    Enter Login Credentials
    Navigate To Inbox Page
    Filter Activity And Country
    Click On IRN Filter To Get Latest IRN
    ${irn}=    Get Latest IRN
    Open IRN Page    ${irn}
    Select Activity Dropdown
    Submit button
    ${status}=    Run Keyword And Return Status    Wait Until Element Contains    id=statusMessage    Submitted    timeout=5s
    ${activity}=    Get Value    id=txtActivity_Code
    IF    ${status}
        ${message}=    Set Variable    Success
    ELSE
        ${message}=    Get Text    xpath=//ul[contains(@class,"un-oder")]
    END
    ${result}=    Create Dictionary    IRN=${irn}    Status=${activity}    Message=${message}
    Get Data in JSON    ${result}

*** Keywords ***
Enter Login Credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}    ${VALID USERNAME}
    Input Text    ${password_field}    ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    xpath=//h1[text()='Activity Matrix']    timeout=10s

Navigate To Inbox Page
    Click Element    xpath=//a[.//span[text()='Inbox']]
    Wait Until Element Is Visible    xpath=//a[.//span[text()='Inbox']]    timeout=10s
    Sleep    2s

Filter Activity And Country
    Execute JavaScript    document.getElementById("selectActivityCode").style.display = 'block'
    Select From List By Label    id=selectActivityCode    ${Activity_Name}
    Sleep    2s
    Execute JavaScript    document.getElementById("selectPlant").style.display = 'block'
    Select From List By Label    id=selectPlant    ${Country_Name}
    Sleep    2s

Click On IRN Filter To Get Latest IRN
    Wait Until Element Is Visible    ${IRN_Filter}    timeout=10s
    Click Element    ${IRN_Filter}
    Sleep    3s
    ${refilter}=    Get WebElement    ${IRN_Filter}
    Click Element    ${refilter}
    Sleep    2s
    ${refilter}=    Get WebElement    ${IRN_Filter}
    Click Element    ${refilter}
    Sleep    2s
    Wait Until Element Is Visible    ${Recent_IRN}    timeout=10s

Get Latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}    timeout=10s
    ${irn}=    Get Text    ${Recent_IRN}

    Log To Console    Latest IRN: ${irn}
    RETURN    ${irn}

Open IRN Page
    [Arguments]    ${irn}
    Click Element    xpath=//a[text()='${irn}']
    Wait Until Page Contains Element    id=Update2    timeout=15s

Select Activity Dropdown
    Scroll Element Into View    id=Activity_Code_label
    Wait Until Element Is Not Visible    //div[@class='transaction-modal-footer']    timeout=10s
    ${Dropdown_Arrow}=    Set Variable    //label[@id='Activity_Code_label']/following::span[contains(@class,'k-dropdown-wrap')][1]
    Wait Until Element Is Visible    ${Dropdown_Arrow}    timeout=10s
    Execute JavaScript    document.evaluate(`${Dropdown_Arrow}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()
    Sleep    0.5s
    Wait Until Element Is Visible    //ul[@id="Activity_Code_listbox"]//li[normalize-space()='Send For Match']    timeout=10s
    Click Element    //ul[@id="Activity_Code_listbox"]//li[normalize-space()='Send For Match']
    Log To Console    ✅ Selected Activity: Send For Match

Submit button
    Click Element    //input[@id="Update2"]
    Log To Console    Submit button clicked
    Sleep    2s

Get Data in JSON
    [Arguments]    ${entry}
    ${data}=    Create List
    Append To List    ${data}    ${entry}
    ${json_data}=    Evaluate    json.dumps(${data}, indent=2)    json
    Log To Console    Data in JSON: ${json_data}

