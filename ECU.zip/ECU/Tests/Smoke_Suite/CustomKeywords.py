from SeleniumLibrary import SeleniumLibrary
from robot.api.deco import keyword
from robot.libraries.BuiltIn import BuiltIn
from selenium.common.exceptions import NoSuchElementException


@keyword("Submit IRN For Matching")
def submit_irn_for_matching(irn: str):
    seleniumlib: SeleniumLibrary = BuiltIn().get_library_instance("SeleniumLibrary")

    # Step 1: Click on the IRN number to open detail
    seleniumlib.click_element(f"xpath=//a[text()='{irn}']")

    # Step 2: Wait until dropdown field is visible
    seleniumlib.wait_until_element_is_visible("id=Activity_Code", timeout="10s")

    # Step 3: Use JavaScript to select the Kendo dropdown option
    dropdown_id = "Activity_Code"
    label = "Send For Match"
    js = (
        f"var dropdown = $('#{dropdown_id}').data('kendoDropDownList');"
        f"if (dropdown) {{"
        f"dropdown.select(function(dataItem) {{ return dataItem.text === '{label}'; }});"
        f"dropdown.trigger('change');"
        f"}}"
    )
    seleniumlib.execute_javascript(js)
    seleniumlib.sleep("1s")

    # Step 4: Click submit button
    seleniumlib.click_button("id=Update2")

    # Step 5: Check for validation error messages
    error_visible = seleniumlib.run_keyword_and_return_status(
        "Element Should Be Visible", "id=validationInnerDiv"
    )

    if error_visible:
        try:
            errors = seleniumlib.get_webelements("xpath=//div[@id='validationInnerDiv']//li/span[@class='err-span']")
            error_texts = [e.text for e in errors]
            error_string = " |".join(error_texts)
            return irn, "not submitted", error_string
        except NoSuchElementException:
            return irn, "not submitted", "Unknown error (elements not found)"

    return irn, "submitted", ""
