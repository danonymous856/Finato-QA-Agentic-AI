import pyodbc
import pandas as pd

DB_CONN_STR = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=192.168.41.82,9093;"
    "DATABASE=IPM-ECU;"
    "UID=Donald.L;"
    "PWD=Datamatics@3544"  # <--- Change this as needed
)

def get_db_connection():
    return pyodbc.connect(DB_CONN_STR)

def fetch_invoice_lines(irn, conn):
    query = f"""
        SELECT * FROM [ipm-core].IPM_ME_InvoiceLineSummary
        WHERE InvoiceTranId = {irn}
    """
    return pd.read_sql(query, conn)

def extract_primary_values(invoice_df):
    vals = {}
    cols = {
        'BL': ['PO_Number', 'ItemNumber', 'ConvertedPer'],
        'NrTruck': ['Part_No'],
        'NrFile': ['Reference_Number']
    }
    for est_col, inv_cols in cols.items():
        s = set()
        for inv_col in inv_cols:
            if inv_col in invoice_df.columns:
                s.update(str(v).strip() for v in invoice_df[inv_col] if str(v).strip() and str(v).strip().upper() != 'NAN')
        vals[est_col] = s
    return vals

def fetch_candidate_estimates(vals, conn):
    def _sql_in(values):
        return ','.join(f"'{v}'" for v in values) if values else "''"
    bl_values = vals.get('BL', set())
    nrtruck_values = vals.get('NrTruck', set())
    nrfile_values = vals.get('NrFile', set())

    estimate_where = []
    if bl_values:
        estimate_where.append(f"UPPER(BL) IN ({_sql_in(bl_values)})")
    if nrtruck_values:
        estimate_where.append(f"UPPER(NrTruck) IN ({_sql_in(nrtruck_values)})")
    if nrfile_values:
        estimate_where.append(f"UPPER(NrFile) IN ({_sql_in(nrfile_values)})")
    estimate_sql = " OR ".join(estimate_where) if estimate_where else "1=0"

    estimate_query = f"""
        SELECT * FROM [ipm-data].tblEstimateMaster_Data
        WHERE LegalEntityID='1' AND ({estimate_sql})
    """

    filedetail_where = []
    if bl_values:
        filedetail_where.append(f"UPPER(BL) IN ({_sql_in(bl_values)})")
    if nrfile_values:
        filedetail_where.append(f"UPPER(NrFile) IN ({_sql_in(nrfile_values)})")
    filedetail_sql = " OR ".join(filedetail_where) if filedetail_where else "1=0"

    filedetail_query = f"""
        SELECT * FROM [ipm-data].tblFileDetailMaster_Data
        WHERE LegalEntityID='1' AND ({filedetail_sql})
    """

    df1 = pd.read_sql(estimate_query, conn)
    df2 = pd.read_sql(filedetail_query, conn)
    return pd.concat([df1, df2], ignore_index=True)

def match_invoice_line(inv_row, estimate_df):
    primary_vals = {
        'BL': [inv_row.get('PO_Number', ''), inv_row.get('ItemNumber', ''), inv_row.get('ConvertedPer', '')],
        'NrTruck': [inv_row.get('Part_No', '')],
        'NrFile': [inv_row.get('Reference_Number', '')]
    }
    found_primary = False
    best_failure = None
    for est_col, inv_vals in primary_vals.items():
        for inv_val in inv_vals:
            val = str(inv_val).strip().upper()
            if not val:
                continue
            matches = estimate_df[estimate_df[est_col].apply(lambda x: str(x).strip().upper()) == val]
            if not matches.empty:
                found_primary = True
                for _, est_row in matches.iterrows():
                    invoice_currency = str(inv_row.get('Currency', '')).strip().upper()
                    # Try both ExpCurrency and Currency for estimates
                    estimate_currency = str(est_row.get('ExpCurrency', '') or est_row.get('Currency', '')).strip().upper()
                    # Debug print for validation
                    # print(f"DEBUG: InvoiceLineTranId={inv_row.get('InvoiceLineTranId','')}, Invoice Currency='{invoice_currency}', Estimate Currency='{estimate_currency}'")

                    explanation_lines = []
                    if invoice_currency != estimate_currency:
                        explanation_lines.append(f"Currency mismatch: {invoice_currency} vs {estimate_currency}")
                        if best_failure is None:
                            best_failure = ("Estimates Mismatch", "; ".join(explanation_lines))
                        continue

                    # Amount matching logic (use InvoiceLineAmountWithTax for all currencies)
                    inv_amt = float(inv_row.get('InvoiceLineAmountWithTax', 0) or 0)
                    if invoice_currency == "GBP":
                        est_amt = float(est_row.get('Amount', 0) or 0)
                        explanation_lines.append(
                            f"Amount used for matching (GBP): Invoice InvoiceLineAmountWithTax={inv_amt} vs Estimate Amount={est_amt}"
                        )
                    else:
                        est_qty = float(est_row.get('Quantity', 0) or 0)
                        est_price = float(est_row.get('ExpPrice', 0) or 0)
                        est_amt = est_qty * est_price
                        explanation_lines.append(
                            f"Amount used for matching (Non-GBP): Invoice InvoiceLineAmountWithTax={inv_amt} vs Estimate Quantity*ExpPrice={est_amt}"
                        )
                    amt_diff = abs(inv_amt - est_amt)
                    if amt_diff > 5:
                        explanation_lines.append(
                            f"Amount diff > 5: {inv_amt} vs {est_amt} (diff={amt_diff})"
                        )
                        if best_failure is None:
                            best_failure = ("Estimates Mismatch", "; ".join(explanation_lines))
                        continue
                    else:
                        explanation_lines.append(
                            f"Amount diff <= 5: {inv_amt} vs {est_amt} (diff={amt_diff})"
                        )

                    inv_seq = str(inv_row.get('HSN_SAC_Code', '')).strip()
                    est_seq = str(est_row.get('BlSeq', '')).strip() if 'BlSeq' in est_row else ''
                    if inv_seq and inv_seq != "0" and inv_seq.upper() != "NAN":
                        if inv_seq == est_seq:
                            explanation_lines.append(f"Sequence match: {inv_seq} vs {est_seq}")
                        else:
                            explanation_lines.append(f"Sequence mismatch: {inv_seq} vs {est_seq}")
                            if best_failure is None:
                                best_failure = ("Estimates Mismatch", "; ".join(explanation_lines))
                            continue

                    # If got this far: all secondary checks passed!
                    return "Matched", "; ".join(explanation_lines)
    if found_primary:
        return best_failure if best_failure else ("Estimates Mismatch", "All primary matched, secondary failed")
    else:
        return "Estimates Missing", "No matching estimate found for primary parameters"

def validate_irn(irn):
    conn = get_db_connection()
    invoice_df = fetch_invoice_lines(irn, conn)
    # Print headers and first few rows for debug
    print("\n--- [ipm-core].IPM_ME_InvoiceLineSummary ---")
    print("Columns:", list(invoice_df.columns))
    print(invoice_df.head(5))
    primary_vals = extract_primary_values(invoice_df)
    estimate_df = fetch_candidate_estimates(primary_vals, conn)
    print("\n--- [ipm-data].tblEstimateMaster_Data & tblFileDetailMaster_Data (Combined) ---")
    print("Columns:", list(estimate_df.columns))
    print(estimate_df.head(5))
    results = []
    for idx, inv_row in invoice_df.iterrows():
        expected_status, explanation = match_invoice_line(inv_row, estimate_df)
        actual_status = inv_row.get('ErrorMessage', '')
        result = "PASS" if expected_status == actual_status else "FAIL"
        results.append({
            "InvoiceLineTranId": inv_row.get('InvoiceLineTranId', ''),
            "ActualErrorMessage": actual_status,
            "ExpectedStatus": expected_status,
            "Result": result,
            "Explanation": explanation
        })
    report_path = f"D:\\Finato_Automation\\ECU\\Tests\\Regression_Suite\\Matching Exceptions_{irn}.csv"
    pd.DataFrame(results).to_csv(report_path, index=False)
    print(f"\nValidation Report for IRN={irn} saved to {report_path}")
    return report_path

if __name__ == "__main__":
    irn = input("Enter InvoiceTranId (IRN): ")
    validate_irn(irn)