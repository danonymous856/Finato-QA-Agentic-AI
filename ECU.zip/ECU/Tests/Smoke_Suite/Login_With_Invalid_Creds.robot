*** Settings ***
Library           SeleniumLibrary
Resource         ../../Resources/Keywords/Global_Keywords.robot
Test Template     Login with invalid credentials should fail
Suite Setup       Open Browser To Login Page
Suite Teardown    Close Browser
Force Tags       Regression

*** Test Cases ***                USERNAME          PASSWORD
Invalid User Name                 invalid           ${VALID PASSWORD}
Invalid Password                  ${VALID USERNAME}     invalid
Invalid User Name and Password    invalid           invalid
Empty User Name                   ${EMPTY}          ${VALID PASSWORD}
Empty Password                    ${VALID USERNAME}     ${EMPTY}
Empty User Name and Password      ${EMPTY}          ${EMPTY}

*** Keywords ***
Open Browser To Login Page
    Open Browser    ${LOGIN URL}    ${BROWSER}
    Maximize Browser Window
    Wait Until Page Contains Element    id=login
    Click Continue Login


Login with invalid credentials should fail
    [Arguments]    ${username}    ${password}
    Input Text     id=User_Name      ${username}
    Input Text     id=User_Password  ${password}
    Click Button   id=login
    ${error_msg}=  Run Keyword And Return Status    Wait Until Page Contains Element    id=toast_msg    timeout=10
    Run Keyword If    ${error_msg}
    ...    Log    Error message is displayed for invalid login credentials
    Capture Page Screenshot    ${username}-${password}-failure.png
    Should Be True    ${error_msg}    Error message not displayed as expected.
    [Teardown]    Clear Inputs

Clear Inputs
    Clear Element Text    id=User_Name
    Clear Element Text    id=User_Password
