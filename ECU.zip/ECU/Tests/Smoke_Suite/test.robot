*** Settings ***
Library    SeleniumLibrary
Library    BuiltIn
Library    String
Library    XML
Library    Dialogs
#Library    compare_utils.py
Library    test.py
Resource   ../../Resources/Keywords/Global_Keywords.robot
Resource   ../../Resources/Pages/LoginPage.robot
Resource   ../../Resources/Pages/HomePage.robot
Resource   ../../Resources/Pages/InboxPage.robot
Resource   ../../Resources/Pages/InvoiceTranscationDetailPage.robot
Resource   ../../Resources/Pages/SearchPage.robot

*** Variables ***
${URL}       https://finato-uat.i-processmanager.com/IPMV4/Login/
${BROWSER}   chrome
${TARGET_IRN}    ${EMPTY}

${INVOICE_FIRST_ROW_XPATH}          //div[@id='invoicelineitemGrid']//tbody/tr[1]
${ESTIMATE_FIRST_ROW_XPATH}         //div[@id='polineitemGrid']//tbody/tr[1]

${INVOICE_HEADERS_XPATH}            //div[@id='invoicelineitemGrid']//thead//th
${ESTIMATE_HEADERS_XPATH}           //div[@id='polineitemGrid']//thead//th

${INVOICE_ROWS_XPATH}               //div[@id='invoicelineitemGrid']//tbody/tr
${ESTIMATE_ROWS_XPATH}              //div[@id='polineitemGrid']//tbody/tr

${INVOICE_CELL_XPATH_TEMPLATE}      //div[@id='invoicelineitemGrid']//tbody/tr[{row}]/td[{col}]
${ESTIMATE_CELL_XPATH_TEMPLATE}     //div[@id='polineitemGrid']//tbody/tr[{row}]/td[{col}]

*** Test Cases ***
Match Invoice To Estimate
    [Documentation]    Full flow to match invoice and estimate using BL, currency, and amount.
    ${TARGET_IRN}=    Get IRN From User
    Set Global Variable    ${TARGET_IRN}    # Make it available throughout the test
    Open Browser To Login Page
    Enter Login Credentials
    Navigate to Filter page
    Click New Target IRN
    Click on IRN filter to filter the recent IRN
    Click on latest IRN
    Click Matching Icon
    Extract Table Data As JSON
    Match Invoice To Estimate
    Close Browser

*** Keywords ***
Get IRN From User
    ${TARGET_IRN}=    Get Value From User    Enter the IRN number:    default_value=${EMPTY}
    [Return]    ${TARGET_IRN}

Enter Login Credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}   ${VALID USERNAME}
    Input Text    ${password_field}   ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']  timeout=10s

Navigate to Filter page
    Click Element    //span[@title='Search']
    Wait Until Page Contains Element    xpath=//h6[text()='Filter']   timeout=10s

Click New Target IRN
    Wait Until Element Is Visible    xpath=//input[@id='txtdrn']    timeout=5s
    Input Text      xpath=//input[@id='txtdrn']   ${TARGET_IRN}
    Click Element    ${SUBMIT_BUTTON}

Click on IRN filter to filter the recent IRN
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}

Click on latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}
    Click Element    ${Recent_IRN}
    Wait Until Element Is Visible    ${InvoiceNumber}    timeout=10s

Wait Until Number Of Windows Is
    [Arguments]    ${expected}=2    ${timeout}=10s
    Wait Until Keyword Succeeds    ${timeout}    1s
    ...    Run Keyword And Return Status    Check Window Count    ${expected}

Check Window Count
    [Arguments]    ${expected}
    ${handles}=    Get Window Handles
    ${count}=      Get Length    ${handles}
    Should Be Equal As Integers    ${count}    ${expected}

Click Matching Icon
    [Documentation]    Clicks Matching icon, waits for new tab, switches to it, waits for invoice table to load, then matches.
    ${before}=    Get Window Handles
    ${before_count}=    Get Length    ${before}
    Click Element    xpath=//a[@id='btnMatching']
    Log    clicked on matching button
    Wait Until Number Of Windows Is   ${before_count + 1}
    Switch Window   NEW
    Wait Until Element Is Visible    xpath=//div[@id='polineitemGrid']    timeout=15s
    Log    Estimate section is loaded successfully

Extract Table Data As JSON
    [Documentation]    Extracts invoice and estimate table data as JSON dictionaries using headers for row-wise mapping.
    Wait Until Element Is Visible    ${INVOICE_FIRST_ROW_XPATH}    timeout=15s
    Wait Until Element Is Visible    ${ESTIMATE_FIRST_ROW_XPATH}    timeout=15s
    Sleep    1s

    ### INVOICE TABLE
    ${invoice_headers}=    Create List
    ${invoice_header_elements}=    Get WebElements    ${INVOICE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{invoice_header_elements}
        ${header}=    SeleniumLibrary.Get Element Attribute    ${header_el}    data-title
        Run Keyword If    '${header}' == '' or '${header}' == None    ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${invoice_headers}    ${header}
    END

    ${invoice_row_count}=    SeleniumLibrary.Get Element Count    ${INVOICE_ROWS_XPATH}
    ${invoice_data}=    Create List

    ${invoice_col_count}=    Get Length    ${invoice_headers}
    FOR    ${i}    IN RANGE    1    ${invoice_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${invoice_col_count + 1}
            ${row_str}=    Convert To String    ${i}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${INVOICE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${invoice_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
        END
        Append To List    ${invoice_data}    ${row}
    END

#    ${invoice_json}=    Evaluate    json.dumps(${invoice_data}, indent=2)    json
#    Log    INVOICE TABLE JSON:
#    Log    ${invoice_json}

    ### ESTIMATE TABLE
    ${estimate_headers}=    Create List
    ${estimate_header_elements}=    Get WebElements    ${ESTIMATE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{estimate_header_elements}
        ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${estimate_headers}    ${header}
    END

    ${estimate_row_count}=    SeleniumLibrary.Get Element Count    ${ESTIMATE_ROWS_XPATH}
    ${estimate_data}=    Create List

    ${estimate_col_count}=    Get Length    ${estimate_headers}
    FOR    ${j}    IN RANGE    1    ${estimate_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${estimate_col_count + 1}
            ${row_str}=    Convert To String    ${j}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${ESTIMATE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${estimate_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
            Set To Dictionary    ${row}    ${estimate_headers[${col_index - 1}]}=${value}
        END
        Append To List    ${estimate_data}    ${row}
    END

#    ${estimate_json}=    Evaluate    json.dumps(${estimate_data}, indent=2)    json
#    Log    ESTIMATE TABLE JSON:
#    Log    ${estimate_json}
#    Log To Console    ${invoice_json}
#    Log To Console    ${estimate_json}
    [Return]    ${invoice_data}    ${estimate_data}


Match Invoice To Estimate
    ${invoice_data}    ${estimate_data}=    Extract Table Data As JSON
    ${best_results}    ${all_comparisons}=    Evaluate    test.compare_invoice_and_estimate_rows(${invoice_data}, ${estimate_data})    test

    ### CALL THE NEW LOGGER HERE ###
#    Evaluate    test.log_comparison_result(${all_comparisons})    test
#    Evaluate    test.log_comparison_result(${best_results}, best_only=True)    test

    ${all_valid}=    Evaluate    all(r.get("finato_validated", True) for r in ${best_results})    test
    Should Be True    ${all_valid}    One or more FINATO matches failed validation!

#Compare Invoice and Estimate Rows
#    [Documentation]    Compares invoice and estimate rows using key mapping and logs results.
#    [Arguments]    ${invoice_data}    ${estimate_data}
#
#    &{key_map}=    Create Dictionary
#    ...    Currency=Currency
#    ...    Sequence Number=Sequence Number
#    ...    Item Description=Description
#    ...    Unit Price=Exp Price
#    ...    Line Amount=Line Amount(Quantity*ExpPrice)
#    ...    Container Number=BL Number
#    ...    File Number=File Number
#
#    ${inv_index}=   Set Variable    0
#    FOR    ${invoice_row}    IN    @{invoice_data}
#        ${inv_index}=    Evaluate    ${inv_index} + 1
#        ${est_index}=    Set Variable   0
#        FOR    ${estimate_row}    IN    @{estimate_data}
#            ${est_index}=    Evaluate    ${est_index} + 1
#            Log To Console     Comparing Invoice Row ${inv_index} x Estimate Row ${est_index}:
#
#            ${invoice_keys}=    Get Dictionary Keys    ${invoice_row}
#            ${compare_keys}=    Create List
#            FOR    ${inv_key}    IN    @{invoice_keys}
#                ${est_key}=    Get From Dictionary    ${key_map}    ${inv_key}    default=None
#                Run Keyword If    '${est_key}' != 'None'    Append To List    ${compare_keys}    ${inv_key}
#            END
#
#            ${match_count}=    Set Variable    ${0}
#            ${total}=          Get Length    ${compare_keys}
#
#            FOR    ${key}    IN    @{compare_keys}
#                ${est_key}=    Get From Dictionary    ${key_map}    ${key}    default=${key}
#                ${inv_value}=    Get From Dictionary    ${invoice_row}    ${key}    default=
#                ${est_value}=    Get From Dictionary    ${estimate_row}    ${est_key}    default=
#
#                ${match}=    Set Variable    ${false}
#
##               Seq number condition
#                IF    '${key}' == 'Sequence Number'
#                    ${inv_seq_num}=    Get From Dictionary    ${invoice_row}    Sequence Number    default=
#                    ${est_seq_num}=    Get From Dictionary    ${estimate_row}    Sequence Number    default=
#
#                    IF      '${inv_seq_num}' != '0' and '${inv_seq_num}' != ''
#                        ${match}=    Run Keyword And Return Status    Should Be Equal    ${inv_value}    ${est_value}
#                    ELSE
#                        Log To Console    • Sequence Number is empty or zero, skipping match.
#                        ${match}=    Set Variable    ${False}
#                    END
#
#               Line amount condition (tolerance added)
#                ELSE IF    '${key}' == 'Line Amount'
#                    ${inv_currency}=    Get From Dictionary    ${invoice_row}    GBP (Local currency)    default=
#                    ${est_currency}=    Get From Dictionary    ${estimate_row}    Currency    default=
#                    ${currency_match}=    Run Keyword And Return Status    Should Be Equal    ${inv_currency}    ${est_currency}
#                    IF    ${currency_match}
#                        IF    '${inv_currency}' == 'GBP'
#                            ${est_amount}=    Get From Dictionary    ${estimate_row}    Amount    default=0
#                            ${inv_val}=    Convert To Number    ${inv_value}
#                            ${est_val}=    Convert To Number    ${est_amount}
#                            Log To Console    • Tolerance applied: Invoice Line Amount (${inv_val}) vs Estimate Amount (${est_val})
#                        ELSE
#                            ${est_line_amount}=    Get From Dictionary    ${estimate_row}    Line Amount(Quantity*ExpPrice)    default=0
#                            ${inv_val}=    Convert To Number    ${inv_value}
#                            ${est_val}=    Convert To Number    ${est_line_amount}
#                            Log To Console    • Tolerance applied: Invoice Line Amount (${inv_val}) vs Estimate Line Amount (${est_val})
#                        END
#                        ${lower_limit}=    Evaluate    ${inv_val} - 5
#                        ${upper_limit}=    Evaluate    ${inv_val} + 5
#                        ${match}=    Evaluate    is_within_tolerance(${inv_val}, ${est_val}, 5)    tolerance_utils
#                        Log To Console     Estimate Match Result: ${match}
#                    ELSE
#                        ${match}=    Set Variable    ${False}
#                    END
#
#            ${percent}=    Evaluate    round((${match_count} / ${total}) * 100, 1) if ${total} > 0 else 0
#            Log To Console    ✔️ Match Score: ${match_count}/${total} (${percent}%)
#            Log To Console    -------------------------------------------------------
#        END
#    END
#
#Fuzzy BL Match
#    [Arguments]    ${inv_bl}    ${est_bl}
#    ${inv_clean}=    Evaluate    re.sub(r'[^A-Z0-9]', '', '''${inv_bl}''')    re
#    ${est_clean}=    Evaluate    re.sub(r'[^A-Z0-9]', '', '''${est_bl}''')    re
#    Should Be Equal    ${inv_clean}    ${est_clean}
