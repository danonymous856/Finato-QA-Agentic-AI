# IRNInputBox.py

import tkinter as tk
from tkinter import simpledialog

def get_irns_from_user():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    irns = simpledialog.askstring("IRN Input", "Enter IRNs (comma-separated):\nExample: 886 or 886,883,884")
    if irns:
        with open("irns_input.txt", "w") as f:
            f.write(irns.strip())
    else:
        with open("irns_input.txt", "w") as f:
            f.write("")

if __name__ == "__main__":
    get_irns_from_user()
