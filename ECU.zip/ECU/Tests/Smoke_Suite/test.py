import re
from robot.libraries.BuiltIn import BuiltIn
from tabulate import tabulate
from datetime import datetime
import pandas as pd
import textwrap

# ANSI color codes
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def clean_bl(value):
    return re.sub(r'[^A-Z0-9]', '', value.upper()) if value else ''

def is_within_tolerance(inv_val, est_val, tolerance=5.0):
    try:
        inv_str = str(inv_val).replace(',', '').strip()
        est_str = str(est_val).replace(',', '').strip()
        inv = float(inv_str)
        est = float(est_str)
        return abs(inv - est) <= tolerance, abs(inv - est)
    except ValueError:
        return False, None

def normalize_dict_keys(data_list):
    normalized_list = []
    for row in data_list:
        normalized_row = {}
        for k, v in row.items():
            normalized_key = k.strip().lower().replace(" ", "_")
            normalized_row[normalized_key] = v
        normalized_list.append(normalized_row)
    return normalized_list

def custom_log(msg, color=None, console_color=None):
    if color:
        BuiltIn().log(f"<span style='color:{color}'>{msg}</span>", html=True)
    if console_color:
        BuiltIn().log_to_console(f"{console_color}{msg}{RESET}")
    else:
        BuiltIn().log_to_console(msg)

def log_comparison_result(results, section_title="[ RESULTS ]"):
    custom_log(f"[DEBUG] Calling log_comparison_result with section_title={section_title}", color='purple', console_color=BOLD)
    custom_log("\n" + section_title.center(60, "=") + "\n", console_color=RESET)

    # Summary stats
    total_matches = sum(sum(1 for m in r.get("matches", []) if m["match"] and not m.get("skipped", False)) for r in results)
    total_mismatches = sum(sum(1 for m in r.get("matches", []) if not m["match"] and not m.get("skipped", False)) for r in results)
    total_valid = sum(1 for r in results if r.get("finato_validated", False))
    summary = [
        ["Total Parameters Compared", len(results[0]["matches"]) if results else 0],
        ["Matches", total_matches],
        ["Mismatches", total_mismatches],
        ["Validations Passed", total_valid],
        ["Validations Failed", len(results) - total_valid]
    ]
    custom_log(tabulate(summary, headers=["Metric", "Value"], tablefmt="grid"), console_color=BOLD)

    # Prepare Excel writer
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    excel_filename = f"Excel_Logs/comparison_results_{timestamp}.xlsx"
    writer = pd.ExcelWriter(excel_filename, engine='openpyxl')

    for idx, row_result in enumerate(results):
        inv_row = row_result.get("invoice_row", "?")
        est_row = row_result.get("estimate_row", "?")
        is_aggregated = row_result.get("is_aggregated", False)

        if is_aggregated:
            custom_log(f"[>] COMPARING INVOICE ROW(S) {inv_row} :: ESTIMATE ROW(S) {est_row}", console_color=BOLD)
        else:
            custom_log(f"[>] COMPARING INVOICE ROW {inv_row} :: ESTIMATE ROW {est_row}", console_color=BOLD)
        custom_log("-" * 60, console_color=RESET)

        # Prepare table data for console and Excel
        table_data = []
        critical_mismatches = []
        for match in row_result.get("matches", []):
            key = match["key"]
            inv_val = match["invoice"]
            est_val = match["estimate"]
            status = "[Match]" if match["match"] else "[Mismatch]"
            if match.get("skipped", False):
                status = "[Ignore]"
            console_color = GREEN if match["match"] else RED if not match.get("skipped", False) else RESET

            # Generate parameter description with validation logic
            if key == "association_id":
                param_desc = "Verify Invoice line Association Id with Estimate AssociationID only if invoice value is not null or 0"
                table_data.append([param_desc, f"INVOICE='{inv_val}'", f"ESTIMATE='{est_val}'", status])
            elif key == "sequence_number":
                param_desc = "Verify Sequence Number in the Invoice matches the Sequence Number in the Estimate, only if invoice values are non-zero and non-null"
                table_data.append([param_desc, f"INVOICE='{inv_val}'", f"ESTIMATE='{est_val}'", status])
            elif key in ["bl_number", "bl_number(from_file_details)", "container_number", "container_number(from_file_details)", "ocean_bl"]:
                param_desc = f"Verify {key.replace('_', ' ').title()} in Invoice matches the BL Number in Estimate and Transshipment BL in Estimates, only if invoice value is not null or 0"
                inv_display = f"INVOICE({key}='{inv_val}')"
                est_display = f"ESTIMATE(bl_number='{est_val}')"
                table_data.append([param_desc, inv_display, est_display, status])
                if not match["match"] and not match.get("skipped", False):
                    critical_mismatches.append(key.replace('_', ' ').title())
            elif key == "booking_number":
                param_desc = "Verify Booking Number in Invoice matches the Booking Number in Estimate, only if invoice value is not null or 0"
                inv_display = f"INVOICE(booking_number='{inv_val}')"
                est_display = f"ESTIMATE='{est_val}'"
                table_data.append([param_desc, inv_display, est_display, status])
            elif key == "truck_number":
                param_desc = "Verify Truck Number in Invoice matches the Truck Number in Estimate, only if invoice value is not null or 0"
                inv_display = f"INVOICE(truck_number='{inv_val}')"
                est_display = f"ESTIMATE(truck_number='{est_val}')"
                table_data.append([param_desc, inv_display, est_display, status])
            elif key == "file_number":
                param_desc = "Verify File Number in Invoice matches the File Number in Estimate, only if invoice value is not null or 0"
                inv_display = f"INVOICE(file_number='{inv_val}')"
                est_display = f"ESTIMATE(file_number='{est_val}')"
                table_data.append([param_desc, inv_display, est_display, status])
            elif key == "file_number(from_file_details)":
                param_desc = "Verify File Number(From File Details) in Invoice matches the File Number in Estimate, only if invoice value is not null or 0"
                inv_display = f"INVOICE(file_number(from_file_details)='{inv_val}')"
                est_display = f"ESTIMATE(file_number='{est_val}')"
                table_data.append([param_desc, inv_display, est_display, status])
            elif key == "item_description":
                param_desc = "Verify Item Description in Invoice matches the Description In Estimate"
                table_data.append([param_desc, f"INVOICE='{inv_val}'", f"ESTIMATE='{est_val}'", status])
            elif key == "currency":
                param_desc = "Verify Currency in Invoice matches the Currency In Estimate"
                table_data.append([param_desc, f"INVOICE='{inv_val}'", f"ESTIMATE='{est_val}'", status])
            elif key == "line_amount":
                inv_source = match.get("invoice_source", "line_amount")
                est_source = match.get("estimate_source", "line_amount(quantity*expprice)")
                currency = match.get("currency", "USD")
                if est_source == "amount":
                    param_desc = "Verify Line Amount in Invoice matches the Amount in Estimate, only if invoice line Currency Is GBP within tolerance of +5 & -5"
                else:
                    param_desc = "Verify Line Amount in Invoice matches the line_amount(quantity*expprice) in Estimate, only if invoice line Currency Is Not = GBP within tolerance of +5 & -5"
                table_data.append([param_desc, f"INVOICE({inv_source}='{inv_val}')", f"ESTIMATE({est_source}='{est_val}')", status])
                if not match["match"] and not match.get("skipped", False):
                    critical_mismatches.append("Line Amount")

        # Wrap long parameter descriptions for console output
        wrapped_table_data = []
        for row in table_data:
            param_desc = row[0]
            wrapped_param = "\n".join(textwrap.wrap(param_desc, width=60))
            wrapped_table_data.append([wrapped_param] + row[1:])

        # Log table to console
        custom_log(tabulate(wrapped_table_data, headers=["Parameter", "Invoice Value", "Estimate Value", "Result"], tablefmt="grid"), console_color=RESET)

        # Write to Excel
        excel_data = table_data + [
            ["Current Finato Status", row_result.get("actual_status", ""), "", ""],
            ["Expected Finato Status", row_result.get("expected_status", ""), "", ""]
        ]
        df = pd.DataFrame(excel_data, columns=["Parameter", "Invoice Value", "Estimate Value", "Result"])
        sheet_name = f"Comparison_{idx + 1}"
        df.to_excel(writer, sheet_name=sheet_name, index=False)
        # Adjust column widths in Excel
        worksheet = writer.sheets[sheet_name]
        for col_idx, col in enumerate(df.columns):
            max_length = max(df[col].astype(str).map(len).max(), len(col)) + 2
            worksheet.column_dimensions[chr(65 + col_idx)].width = max_length

        # Log critical mismatches
        if critical_mismatches:
            custom_log(f"WARNING: Critical mismatches detected in: {', '.join(critical_mismatches)}", color='red', console_color=RED)

        # Log validation result
        expected = row_result.get("expected_status", "")
        actual = row_result.get("actual_status", "")
        valid = row_result.get("finato_validated", False)
        validation_status = "[Passed]" if valid else "[Failed]"
        console_color = GREEN if valid else RED
        validation_msg = "" if valid else f" | Mismatch detected. Check: {', '.join(m['key'].replace('_', ' ').title() for m in row_result.get('matches', []) if not m['match'] and not m.get('skipped', False))}"
        custom_log(f"\nValidation Result: {validation_status} Expected='{expected}' | Actual='{actual}'{validation_msg}", color='black', console_color=console_color)
        custom_log("-" * 60, console_color=RESET)
        custom_log("")

    # Save the Excel file
    writer.close()
    custom_log(f"Comparison results exported to {excel_filename}", color='blue', console_color=BOLD)

def compare_invoice_and_estimate_rows(invoice_data, estimate_data):
    invoice_data = normalize_dict_keys(invoice_data)
    estimate_data = normalize_dict_keys(estimate_data)

    all_comparisons = []
    best_matches = []
    top_matches_dict = {}

    primary_keys = [
        "sequence_number", "booking_number", "truck_number", "file_number",
    ]

    secondary_keys = ["currency", "line_amount"]

    key_map = {
        "association_id": "association_id",
        "sequence_number": "sequence_number",
        "currency": "currency",
        "line_amount": "line_amount(quantity*expprice)",
        "file_number": "file_number",
        "file_number(from_file_details)": "file_number",
        "item_description": "description",
        "truck_number": "truck_number",
        "booking_number": "booking_number",
    }

    invoice_bl_keys = [
        "bl_number",
        "bl_number(from_file_details)",
        "container_number",
        "container_number(from_file_details)",
        "ocean_bl",
    ]
    estimate_bl_keys = [
        "bl_number",
        "transhipment_bl_number"
    ]

    for i, inv in enumerate(invoice_data):
        best_result = None
        best_match_count = -1
        best_total = 0

        for j, est in enumerate(estimate_data):
            row_result = {
                "invoice_row": i + 1,
                "estimate_row": j + 1,
                "matches": [],
                "match_count": 0,
                "total": 0
            }

            # Step 1: Check ASSOCIATION_ID
            inv_assoc = inv.get("association_id", "").strip()
            est_assoc = est.get("association_id", "").strip()
            match = inv_assoc == est_assoc
            row_result["matches"].append(
                {"key": "association_id", "invoice": inv_assoc, "estimate": est_assoc, "match": match, "skipped": False})
            row_result["total"] += 1
            if match:
                row_result["match_count"] += 1
            else:
                custom_log(f"[SKIPPED] Association ID mismatch. Invoice='{inv_assoc}' | Estimate='{est_assoc}'",
                    color='orange', console_color=RED)
                all_comparisons.append(row_result)
                continue

            # Step 2: Check BL-related fields individually
            proceed = True
            for inv_key in invoice_bl_keys:
                inv_val = inv.get(inv_key, "").strip()
                match_found = False
                est_val_used = ""
                for est_key in estimate_bl_keys:
                    est_val = est.get(est_key, "").strip()
                    if clean_bl(inv_val) and clean_bl(est_val) and clean_bl(inv_val) == clean_bl(est_val):
                        match_found = True
                        est_val_used = est_val
                        break
                if not est_val_used:
                    est_val_used = est.get(estimate_bl_keys[0], "").strip()

                if inv_val and inv_val != "0":
                    match = match_found
                else:
                    match = False

                row_result["matches"].append({
                    "key": inv_key,
                    "invoice": inv_val,
                    "estimate": est_val_used,
                    "match": match,
                    "skipped": not (inv_val and inv_val != "0")
                })
                row_result["total"] += 1
                if match:
                    row_result["match_count"] += 1
                else:
                    if inv_val and inv_val != "0":
                        proceed = False
                        custom_log(f"[SKIPPED] BL parameter mismatch on '{inv_key}'. Invoice='{inv_val}' | Estimate='{est_val_used}'",
                            color='red', console_color=RED)

            # Step 3: Primary key check
            if proceed:
                for key in primary_keys:
                    if key == "file_number":
                        # Handle file_number and file_number(from_file_details) separately
                        inv_val = inv.get("file_number", "").strip()
                        est_val = est.get("file_number", "").strip()
                        match = inv_val == est_val if inv_val and inv_val != "0" else False
                        row_result["matches"].append(
                            {"key": "file_number", "invoice": inv_val, "estimate": est_val, "match": match, "skipped": not (inv_val and inv_val != "0")})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                        else:
                            if inv_val and inv_val != "0":
                                proceed = False
                                custom_log(f"[SKIPPED] Primary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                                    color='red', console_color=RED)

                        # Check file_number(from_file_details)
                        inv_val = inv.get("file_number(from_file_details)", "").strip()
                        match = inv_val == est_val if inv_val and inv_val != "0" else False
                        row_result["matches"].append(
                            {"key": "file_number(from_file_details)", "invoice": inv_val, "estimate": est_val, "match": match, "skipped": not (inv_val and inv_val != "0")})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                        else:
                            if inv_val and inv_val != "0":
                                proceed = False
                                custom_log(f"[SKIPPED] Primary parameter mismatch on 'file_number(from_file_details)'. Invoice='{inv_val}' | Estimate='{est_val}'",
                                    color='red', console_color=RED)
                    else:
                        inv_val = inv.get(key, "").strip()
                        est_key = key_map[key] if key in key_map else key
                        est_val = est.get(est_key, "").strip()
                        match = inv_val == est_val if inv_val and inv_val != "0" else False
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match, "skipped": not (inv_val and inv_val != "0")})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                        else:
                            if inv_val and inv_val != "0" and key != "booking_number":
                                proceed = False
                                custom_log(f"[SKIPPED] Primary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                                    color='red', console_color=RED)

            # Step 4: Secondary key check
            if proceed:
                for key in secondary_keys:
                    inv_val = inv.get(key, "").strip()
                    est_key = key_map[key] if key in key_map else key
                    est_val = est.get(est_key, "").strip()

                    if key == "line_amount":
                        currency = inv.get("currency", "").strip().upper()
                        # Check against estimate "amount" if currency is GBP
                        if currency == "GBP":
                            est_val = est.get("amount", "").strip()
                            match, diff = is_within_tolerance(inv_val, est_val)
                            tolerance_status = "within tolerance" if match else f"out of tolerance (diff: {diff})"
                            row_result["matches"].append({
                                "key": key,
                                "invoice": inv_val,
                                "estimate": est_val,
                                "match": match,
                                "currency": currency,
                                "invoice_source": "line_amount",
                                "estimate_source": "amount",
                                "skipped": False,
                                "tolerance_status": tolerance_status
                            })
                        else:
                            est_val = est.get("line_amount(quantity*expprice)", "").strip()
                            match, diff = is_within_tolerance(inv_val, est_val)
                            tolerance_status = "within tolerance" if match else f"out of tolerance (diff: {diff})"
                            row_result["matches"].append({
                                "key": key,
                                "invoice": inv_val,
                                "estimate": est_val,
                                "match": match,
                                "currency": currency,
                                "invoice_source": "line_amount",
                                "estimate_source": "line_amount(quantity*expprice)",
                                "skipped": False,
                                "tolerance_status": tolerance_status
                            })
                    else:
                        match = inv_val == est_val
                        tolerance_status = ""
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match, "skipped": False, "tolerance_status": tolerance_status})

                    row_result["total"] += 1
                    if match:
                        row_result["match_count"] += 1
                    if not match and key != "line_amount":
                        custom_log(f"[SKIPPED] Secondary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                            color='red', console_color=RED)

            # Step 5: Additional keys from key_map
            additional_keys = [k for k in key_map if k not in primary_keys + secondary_keys + invoice_bl_keys + ["association_id", "line_amount"]]
            for key in additional_keys:
                inv_val = inv.get(key, "").strip()
                est_key = key_map[key] if key in key_map else key
                est_val = est.get(est_key, "").strip()
                match = inv_val == est_val if inv_val and inv_val != "0" else False
                row_result["matches"].append(
                    {"key": key, "invoice": inv_val, "estimate": est_val, "match": match, "skipped": not (inv_val and inv_val != "0")})
                row_result["total"] += 1
                if match:
                    row_result["match_count"] += 1

            all_comparisons.append(row_result)

            if row_result["match_count"] > best_match_count:
                best_result = row_result
                best_match_count = row_result["match_count"]
                best_total = row_result["total"]

        if best_result and best_match_count > 0:
            expected_status = "Matched" if best_match_count == best_total else "Estimates Mismatch"
            actual_status = inv.get("finato_matching_status", "").strip()
            best_result["expected_status"] = expected_status
            best_result["actual_status"] = actual_status
            best_result["finato_validated"] = (expected_status == actual_status)
            best_matches.append(best_result)
            top_matches_dict[(best_result["invoice_row"], best_result["estimate_row"])] = best_result
        else:
            custom_log(f"[SKIPPED] No valid match found for Invoice Row {i + 1}", color='orange', console_color=RED)
            best_matches.append({
                "invoice_row": i + 1,
                "estimate_row": "-",
                "matches": [],
                "match_count": 0,
                "total": 0,
                "expected_status": "Estimates Mismatch",
                "actual_status": inv.get("finato_matching_status", "").strip(),
                "finato_validated": False
            })

    # Aggregation Filter: Support many-to-many matching
    invoice_groups = {}
    for i, inv in enumerate(invoice_data):
        assoc_id = inv.get("association_id", "").strip()
        currency = inv.get("currency", "").strip().upper()
        bl_val = ""
        bl_source = ""
        for inv_key in invoice_bl_keys:
            if inv.get(inv_key, "").strip() and inv.get(inv_key, "").strip() != "0":
                bl_val = inv.get(inv_key, "").strip()
                bl_source = inv_key
                break
        if not bl_val:
            continue
        group_key = (assoc_id, currency, clean_bl(bl_val))
        if group_key not in invoice_groups:
            invoice_groups[group_key] = {
                "invoice_rows": [],
                "line_amounts": [],
                "bl_val": bl_val,
                "bl_source": bl_source
            }
        invoice_groups[group_key]["invoice_rows"].append(i + 1)
        invoice_groups[group_key]["line_amounts"].append(inv.get("line_amount", "0").strip())

    estimate_groups = {}
    for j, est in enumerate(estimate_data):
        assoc_id = est.get("association_id", "").strip()
        currency = est.get("currency", "").strip().upper()
        bl_val = ""
        bl_source = ""
        for est_key in estimate_bl_keys:
            if est_key == "transhipment_bl_number" and not est.get(est_key, "").strip():
                continue
            if est.get(est_key, "").strip():
                bl_val = est.get(est_key, "").strip()
                bl_source = est_key
                break
        if not bl_val:
            continue
        group_key = (assoc_id, currency, clean_bl(bl_val))
        if group_key not in estimate_groups:
            estimate_groups[group_key] = {
                "estimate_rows": [],
                "line_amounts": [],
                "bl_val": bl_val,
                "bl_source": bl_source
            }
        estimate_groups[group_key]["estimate_rows"].append(j + 1)
        estimate_groups[group_key]["line_amounts"].append(est.get("line_amount(quantity*expprice)", "0").strip())

    aggregated_matches = []
    aggregated_invoice_rows = set()
    aggregated_estimate_rows = set()
    for group_key in set(invoice_groups.keys()) & set(estimate_groups.keys()):
        inv_group = invoice_groups[group_key]
        est_group = estimate_groups[group_key]
        if len(inv_group["invoice_rows"]) > 1 or len(est_group["estimate_rows"]) > 1:
            inv_rows_str = ",".join(str(r) for r in sorted(inv_group["invoice_rows"]))
            est_rows_str = ",".join(str(r) for r in sorted(est_group["estimate_rows"]))
            summed_inv_amount = sum(float(amt.replace(',', '')) for amt in inv_group["line_amounts"] if amt)
            summed_est_amount = sum(float(amt.replace(',', '')) for amt in est_group["line_amounts"] if amt)
            line_amount_match, diff = is_within_tolerance(summed_inv_amount, summed_est_amount)
            tolerance_status = "within tolerance" if line_amount_match else f"out of tolerance (diff: {diff})"

            matches = [
                {
                    "key": "association_id",
                    "invoice": group_key[0],
                    "estimate": group_key[0],
                    "match": True,
                    "skipped": False
                },
                {
                    "key": inv_group["bl_source"],
                    "invoice": inv_group["bl_val"],
                    "estimate": est_group["bl_val"],
                    "match": True,
                    "skipped": False
                },
                {
                    "key": "currency",
                    "invoice": group_key[1],
                    "estimate": group_key[1],
                    "match": True,
                    "skipped": False
                },
                {
                    "key": "line_amount",
                    "invoice": str(summed_inv_amount),
                    "estimate": str(summed_est_amount),
                    "match": line_amount_match,
                    "currency": group_key[1],
                    "invoice_source": "line_amount",
                    "estimate_source": "line_amount(quantity*expprice)",
                    "skipped": False,
                    "tolerance_status": tolerance_status
                }
            ]

            additional_keys = [k for k in key_map if k not in primary_keys + secondary_keys + invoice_bl_keys + ["association_id", "line_amount"]]
            for key in additional_keys:
                inv_val = inv.get(key, "").strip()
                est_key = key_map[key] if key in key_map else key
                est_val = est.get(est_key, "").strip()
                match = inv_val == est_val if inv_val and inv_val != "0" else False
                matches.append(
                    {"key": key, "invoice": inv_val, "estimate": est_val, "match": match, "skipped": not (inv_val and inv_val != "0")})

            match_count = sum(1 for m in matches if m["match"] and not m.get("skipped", False))
            total = len([m for m in matches if not m.get("skipped", False)])
            aggregated_result = {
                "invoice_row": inv_rows_str,
                "estimate_row": est_rows_str,
                "matches": matches,
                "match_count": match_count,
                "total": total,
                "is_aggregated": True,
                "expected_status": "Matched" if match_count == total else "Estimates Mismatch",
                "actual_status": invoice_data[inv_group["invoice_rows"][0] - 1].get("finato_matching_status", "").strip(),
                "finato_validated": match_count == total and invoice_data[inv_group["invoice_rows"][0] - 1].get("finato_matching_status", "").strip() == "Matched"
            }
            aggregated_matches.append(aggregated_result)
            aggregated_invoice_rows.update(inv_group["invoice_rows"])
            aggregated_estimate_rows.update(est_group["estimate_rows"])

            custom_log(f"[DEBUG] Aggregation required between [INVOICE ROWS {inv_rows_str} :: ESTIMATE ROWS {est_rows_str}]",
                color='blue', console_color=BOLD)

    # Combine best matches and aggregated matches
    filtered_top_matches = []
    matched_invoice_rows = set()
    for inv_row in range(1, len(invoice_data) + 1):
        best_match = next((m for m in best_matches if m["invoice_row"] == inv_row), None)
        if best_match and best_match["estimate_row"] != "-":
            if best_match["invoice_row"] not in aggregated_invoice_rows and best_match["estimate_row"] not in aggregated_estimate_rows:
                filtered_top_matches.append(best_match)
                matched_invoice_rows.add(inv_row)
        elif best_match:
            filtered_top_matches.append(best_match)
            matched_invoice_rows.add(inv_row)

    if aggregated_matches:
        filtered_top_matches.extend(aggregated_matches)
        matched_invoice_rows.update(
            int(row) for m in aggregated_matches for row in m["invoice_row"].split(",")
        )

    for inv_row in range(1, len(invoice_data) + 1):
        if inv_row not in matched_invoice_rows:
            custom_log(f"[ERROR] No match found for Invoice Row {inv_row}", color='red', console_color=RED)
            filtered_top_matches.append({
                "invoice_row": inv_row,
                "estimate_row": "-",
                "matches": [],
                "match_count": 0,
                "total": 0,
                "expected_status": "Estimates Mismatch",
                "actual_status": invoice_data[inv_row - 1].get("finato_matching_status", "").strip(),
                "finato_validated": False
            })

    # Log all results in a single section
    log_comparison_result(filtered_top_matches, section_title="[ RESULTS ]")

    # Validate and fail test if necessary
    all_valid = all(r.get("finato_validated", True) for r in filtered_top_matches)
    if not all_valid:
        BuiltIn().fail("One or more FINATO matches failed validation!")

    return filtered_top_matches, all_comparisons