*** Settings ***
Library             SeleniumLibrary
Library             Process
Resource            ../../Resources/Keywords/Global_Keywords.robot
Resource            ../../Resources/Pages/LoginPage.robot
Resource            ../../Resources/Pages/HomePage.robot
Resource            ../../Resources/Pages/InboxPage.robot
Resource            ../../Resources/Pages/InvoiceTranscationDetailPage.robot
Suite Setup         Open Browser To Login Page
Suite Teardown      Close Browser


*** Test Cases ***
Complete Flow Test and Validate Success
    [Tags]    Smoke     Regression
    verify mismatch of Invoice Amount and Amount HC and error message should genrated

*** Keywords ***
verify mismatch of Invoice Amount and Amount HC and error message should genrated
    Enter Login Credentials
    Click Continue Login
    Click QC Review Local Count
    Click on IRN filter to filter the recent IRN
    click on latest IRN
    Retrieve IRN and Store into Variable
    Delete existing line Item and Click on add button
    Sleep    2s
    Add Line details
    Add header details
    Select activity
    Click on Submit Button
    Verify activity movement of IRN


Enter Login Credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}   ${VALID USERNAME}
    Input Text    ${password_field}   ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']  timeout=10s

Click Continue Login
    Run Keyword And Ignore Error   Wait Until Element Is Visible    ${Feild_LoginContinue}     timeout=05s      error=False
    ${ContinueLogin}=  Is Element Visible  ${Feild_LoginContinue}
    IF    $ContinueLogin==True
        Click Element   ${CheckBox_Continue_Login}
        Click Element   ${button_Submit_Continue}
    END
Is Element Visible
    [Documentation]   Checks and Returns Boolean value
    ...    ex. ${result}=Is Element Visible     ${Locator}
    ...     returns True | False
    [Arguments]     ${Element}
    ${result}=     Run Keyword And Return Status    Element Should Be Visible  ${Element}   10s
    RETURN     ${result}

Click QC Review Local Count
    Wait Until Element Is Visible    ${QC_REVIEW_LOCAL_COUNT}    timeout=10s
    Click Element    ${QC_REVIEW_LOCAL_COUNT}
Click on IRN filter to filter the recent IRN
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}
    Wait Until Element Is Visible   ${IRN_Filter}
    Click Element    ${IRN_Filter}
click on latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}
    Click Element    ${Recent_IRN}
    Wait Until Element Is Visible    ${InvoiceNumber}    10s  # Replace Sleep with this


Delete existing line Item and Click on add button
    Wait Until Element Is Visible    ${IsCheckBox_Present}   10s
    ${Checkbox_present}  Is Element Visible    ${IsCheckBox_Present}
    IF    $Checkbox_present==True
        Click Element   ${ActionCheckBox}
        Wait Until Element Is Visible    ${deleteButton}
        Click Element    ${deleteButton}
        Click Element    ${ConfirmDeletePopup}
        Sleep    5s
        Wait Until Element Is Visible    ${Add_Button}
        Click Element    ${Add_Button}
        Sleep    5s

    ELSE
        Wait Until Element Is Visible    ${Add_Button}
        Click Element    ${Add_Button}
        Sleep    10s
    END
Add Line details
    Wait for element visible and input text    ${Sequence Number}    0
    Wait for element visible and input text    ${Container Number}    0
    Wait for element visible and input text    ${Booking Number}    0
    Wait for element visible and input text    ${BL Number}    0
    Wait for element visible and input text    ${Ocean BL Number}    0
    Wait for element visible and input text    ${File Number}    0
    Wait for element visible and input text    ${Truck Number}    0
    Wait for element visible and input text    ${Item Description}    0
    Wait for element visible and input text    ${Currency}    GBP
    Wait for Element and Click    ${suggestionbox}
    Wait for element visible and input text    ${Quantity}    1
    Wait for Element and Click    ${NUMERIC_WRAP}  # Click the wrapper
    Wait for Element and Input    ${Unit Price Visible}    57
    Wait for element visible and input text    ${Rate}    1
    Wait for element visible and input text    ${VAT Tax Percentage}    0
    Wait for element visible and input text    ${Amount(HC)}    57
    Click Element       ${Save_Button}
Add header details
      # Add invoice Number
      Wait for element visible and input text    ${InvoiceNumber}    4366666
      # Enter Date
      Date Picker    ${invoiceDate}    Feb/5/2000
      # Add Invoice Amount
        # Step 1: Always execute this step
        Wait for Element and Click    ${invoiceAmount}

        # Step 2: Check if the field contains text or value
        ${invoice_value}=    Get Element Attribute    ${InvoiceAmount_INPUT_FIELD}    value

        IF  '${invoice_value}' != '' and '${invoice_value}' != '${EMPTY}'
             Clear Element Text    ${InvoiceAmount_INPUT_FIELD}
             Click Element    ${invoiceAmount}

             Wait for Element and Input    ${InvoiceAmount_INPUT_FIELD}    57
        ELSE
            Wait for Element and Input    ${InvoiceAmount_INPUT_FIELD}    57
        END

# Step 1: Always execute this step
        Wait for Element and Click   ${VAT_Field_Sibling}

        # Step 2: Check if the field contains text or value
        ${vat_value}=    Get Element Attribute    ${VAT_Field}    value

        IF      '${vat_value}' != '' and '${vat_value}' != '${EMPTY}'
            Clear Element Text    ${VAT_Field}
            Click Element   ${VAT_Field_Sibling}
            Wait for Element and Input    ${VAT_Field}    0
        ELSE
            Wait for Element and Input    ${VAT_Field}    0
        END
#click on currency dropdown and clear it and enter
      Wait for Element and Click    ${Currency_Suggesionbox}
      Clear Element Text            ${Currency_Suggesionbox}
      Wait for Element and Input    ${Currency_Suggesionbox}    ${Currency_Value}
      Wait for Element and Click    ${Select_Currency}
#Enter invoice referance number
       Clear Element Text    ${Invoice_ref_number}
       Wait for Element and Input    ${Invoice_ref_number}    112233

      #Enter Exchange Rate

        Wait for Element and Click    ${ExchangeRate_Sibling}

# Step 2: Check if the field contains text or value
        ${exchange_rate_value}=    Get Element Attribute    //input[@id="FileSaveExchange_Rate"]    value
        IF    '${exchange_rate_value}' != '' and '${exchange_rate_value}' != '${EMPTY}'
            Clear Element Text    ${ExchangeRate}
            Wait Until Element Is Visible    ${ExchangeRateError}
            Click Element    ${ExchangeRate_Sibling}
            Press Keys    ${ExchangeRate}    1
        ELSE
         Press Keys    ${ExchangeRate}        1
        END
        Sleep    5s

Select activity
    Scroll Element Into View    ${Activity_Code_Dropdown}
    Wait Until Element Is Not Visible    //div[@class='transaction-modal-footer']    10s
    Wait Until Element Is Visible    ${Dropdown_Arrow}    10s
    Execute JavaScript    document.evaluate(`${Dropdown_Arrow}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();
    Wait Until Element Is Visible    //li[text()='Send For Match']/ancestor::ul[@id="Activity_Code_listbox"]    10s
    Click Element    //ul[@id="Activity_Code_listbox"]//li[@role="option"][normalize-space()="Send For Match"]
#   Select Dropdown by Value    (//div[@id='Activity_Code-list'])[1]    Send For Match


Click on Submit Button
    Wait for Element and Click    //input[@id="Update2"]

Verify activity movement of IRN
    Retrieve Toast Message
    Sleep    2s

    Run Keyword If    '${toast_message}' == 'Transaction ${Current_IRN} saved successfully'    Log    Test Passed: Toast message is Transaction ${Current_IRN} saved successfully
    Run Keyword If    '${toast_message}' != 'Transaction ${Current_IRN} saved successfully'    Fail    Test Failed: Toast message is not Transaction ${Current_IRN} saved successfully



#Validate Invoice Total
#    Sleep    5s
#    Wait Until Element Is Visible    ${XPATH_TOTAL_AMOUNT HC}    timeout=10s
#
#    # Retrieve total amount
#    ${Sum_AmountHC}    Get Text    ${XPATH_TOTAL_AMOUNT HC}
#    Log To Console    Raw Retrieved Total Amount HC: ${Sum_AmountHC}
#
#    # Extract numeric value (remove 'Sum:' and any unwanted text)
#    ${total_amount}    Evaluate    re.sub(r'[^0-9.]', '', '''${Sum_AmountHC}''')    modules=re
#    Log To Console    Cleaned Total Amount: ${total_amount}
#
#    # Use JavaScript to fetch the invoice total directly from the input field
#    ${invoice_totalHeader}    Execute Javascript    return document.querySelector("#FileSaveInvoiceAmount").value;
#    Log To Console    Raw Retrieved Invoice Total: ${invoice_totalHeader}
#
#    # Remove commas if present (ensures correct comparison)
#    ${total_amount}    Replace String    ${total_amount}    ,    ""
#    ${invoice_total}    Replace String    ${invoice_totalHeader}    ,    ""
#
#    # Ensure invoice total is not empty
#    Run Keyword If    '${invoice_total}' == ''    Fail    Invoice Total Amount is empty! Check XPATH or JavaScript.
#
#    #  Compare Total Amount & Invoice Total
#    Run Keyword If    '${total_amount}' == '${invoice_total}'
#    ...    Log To Console     Amounts Match: Test Passed.

















