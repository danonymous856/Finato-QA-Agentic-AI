*** Settings ***
Library    SeleniumLibrary
Library    BuiltIn
Library    String
Library    XML
Library    Dialogs
Library    test.py
Library    allure.robotframework
Resource   ../../Resources/Keywords/Global_Keywords.robot
Resource   ../../Resources/Pages/LoginPage.robot
Resource   ../../Resources/Pages/HomePage.robot
Resource   ../../Resources/Pages/InboxPage.robot
Resource   ../../Resources/Pages/InvoiceTranscationDetailPage.robot
Resource   ../../Resources/Pages/SearchPage.robot

*** Variables ***
${URL}       https://finato-uat.i-processmanager.com/IPMV4/Login/
${BROWSER}   chrome
${TARGET_IRN}    ${EMPTY}

${INVOICE_FIRST_ROW_XPATH}          //div[@id='invoicelineitemGrid']//tbody/tr[1]
${ESTIMATE_FIRST_ROW_XPATH}         //div[@id='polineitemGrid']//tbody/tr[1]

${INVOICE_HEADERS_XPATH}            //div[@id='invoicelineitemGrid']//thead//th
${ESTIMATE_HEADERS_XPATH}           //div[@id='polineitemGrid']//thead//th

${INVOICE_ROWS_XPATH}               //div[@id='invoicelineitemGrid']//tbody/tr
${ESTIMATE_ROWS_XPATH}              //div[@id='polineitemGrid']//tbody/tr

${INVOICE_CELL_XPATH_TEMPLATE}      //div[@id='invoicelineitemGrid']//tbody/tr[{row}]/td[{col}]
${ESTIMATE_CELL_XPATH_TEMPLATE}     //div[@id='polineitemGrid']//tbody/tr[{row}]/td[{col}]

*** Test Cases ***
Match Invoice To Estimate
    [Documentation]    Full flow to match invoice and estimate using BL, currency, and amount.
    [Tags]    regression    invoice_matching
    Attach Allure Feature    Invoice Matching
    Attach Allure Story    Match Invoice and Estimate Rows
    Attach Allure Severity    Critical
    ${TARGET_IRN}=    Get IRN From User
    Set Global Variable    ${TARGET_IRN}    # Make it available throughout the test
    Open Browser To Login Page
    Enter Login Credentials
    Navigate to Filter page
    Click New Target IRN
    Click on IRN filter to filter the recent IRN
    Click on latest IRN
    Click Matching Icon
    Extract Table Data As JSON
    Match Invoice To Estimate
    Close Browser

*** Keywords ***
Get IRN From User
    [Documentation]    Prompts user to input IRN number.
    Attach Allure Step    Prompt user for IRN number
    ${TARGET_IRN}=    Get Value From User    Enter the IRN number:    default_value=${EMPTY}
    [Return]    ${TARGET_IRN}

Enter Login Credentials
    [Documentation]    Inputs username and password and logs in.
    Attach Allure Step    Enter login credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}   ${VALID USERNAME}
    Input Text    ${password_field}   ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']  timeout=10s

Navigate to Filter page
    [Documentation]    Navigates to the filter page.
    Attach Allure Step    Navigate to filter page
    Click Element    //span[@title='Search']
    Wait Until Page Contains Element    xpath=//h6[text()='Filter']   timeout=10s

Click New Target IRN
    [Documentation]    Inputs the target IRN and submits.
    Attach Allure Step    Input and submit target IRN
    Wait Until Element Is Visible    xpath=//input[@id='txtdrn']    timeout=5s
    Input Text      xpath=//input[@id='txtdrn']   ${TARGET_IRN}
    Click Element    ${SUBMIT_BUTTON}

Click on IRN filter to filter the recent IRN
    [Documentation]    Filters by recent IRN.
    Attach Allure Step    Filter by recent IRN
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}

Click on latest IRN
    [Documentation]    Selects the latest IRN.
    Attach Allure Step    Select latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}
    Click Element    ${Recent_IRN}
    Wait Until Element Is Visible    ${InvoiceNumber}    timeout=10s

Wait Until Number Of Windows Is
    [Arguments]    ${expected}=2    ${timeout}=10s
    [Documentation]    Waits until the number of browser windows matches expected.
    Attach Allure Step    Wait for expected number of windows
    Wait Until Keyword Succeeds    ${timeout}    1s
    ...    Run Keyword And Return Status    Check Window Count    ${expected}

Check Window Count
    [Arguments]    ${expected}
    [Documentation]    Checks the number of open browser windows.
    Attach Allure Step    Check window count
    ${handles}=    Get Window Handles
    ${count}=      Get Length    ${handles}
    Should Be Equal As Integers    ${count}    ${expected}

Click Matching Icon
    [Documentation]    Clicks Matching icon, waits for new tab, switches to it, waits for invoice table to load.
    Attach Allure Step    Click matching icon and switch to new tab
    ${before}=    Get Window Handles
    ${before_count}=    Get Length    ${before}
    Click Element    xpath=//a[@id='btnMatching']
    Log    clicked on matching button
    Wait Until Number Of Windows Is   ${before_count + 1}
    Switch Window   NEW
    Wait Until Element Is Visible    xpath=//div[@id='polineitemGrid']    timeout=15s
    Log    Estimate section is loaded successfully

Extract Table Data As JSON
    [Documentation]    Extracts invoice and estimate table data as JSON dictionaries using headers for row-wise mapping.
    Attach Allure Step    Extract invoice and estimate table data
    Wait Until Element Is Visible    ${INVOICE_FIRST_ROW_XPATH}    timeout=15s
    Wait Until Element Is Visible    ${ESTIMATE_FIRST_ROW_XPATH}    timeout=15s
    Sleep    1s

    ### INVOICE TABLE
    ${invoice_headers}=    Create List
    ${invoice_header_elements}=    Get WebElements    ${INVOICE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{invoice_header_elements}
        ${header}=    SeleniumLibrary.Get Element Attribute    ${header_el}    data-title
        Run Keyword If    '${header}' == '' or '${header}' == None    ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${invoice_headers}    ${header}
    END

    ${invoice_row_count}=    SeleniumLibrary.Get Element Count    ${INVOICE_ROWS_XPATH}
    ${invoice_data}=    Create List

    ${invoice_col_count}=    Get Length    ${invoice_headers}
    FOR    ${i}    IN RANGE    1    ${invoice_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${invoice_col_count + 1}
            ${row_str}=    Convert To String    ${i}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${INVOICE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${invoice_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
        END
        Append To List    ${invoice_data}    ${row}
    END

    ### ESTIMATE TABLE
    ${estimate_headers}=    Create List
    ${estimate_header_elements}=    Get WebElements    ${ESTIMATE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{estimate_header_elements}
        ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${estimate_headers}    ${header}
    END

    ${estimate_row_count}=    SeleniumLibrary.Get Element Count    ${ESTIMATE_ROWS_XPATH}
    ${estimate_data}=    Create List

    ${estimate_col_count}=    Get Length    ${estimate_headers}
    FOR    ${j}    IN RANGE    1    ${estimate_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${estimate_col_count + 1}
            ${row_str}=    Convert To String    ${j}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${ESTIMATE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${estimate_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
        END
        Append To List    ${estimate_data}    ${row}
    END

    [Return]    ${invoice_data}    ${estimate_data}

Match Invoice To Estimate
    [Documentation]    Matches invoice and estimate data and validates results.
    Attach Allure Step    Match invoice and estimate data
    ${invoice_data}    ${estimate_data}=    Extract Table Data As JSON
    ${best_results}    ${all_comparisons}=    Evaluate    test.compare_invoice_and_estimate_rows(${invoice_data}, ${estimate_data})    test
    Attach Allure Step    Log comparison results
    Evaluate    test.log_comparison_result(${all_comparisons}, section_title="[ ALL COMPARISONS ]")    test
    Evaluate    test.log_comparison_result(${best_results}, best_only=True, section_title="[ FINAL RESULTS ]")    test
    Attach Allure Step    Validate matching results
    ${all_valid}=    Evaluate    all(r.get("finato_validated", True) for r in ${best_results})    test
    Should Be True    ${all_valid}    One or more FINATO matches failed validation!

Attach Allure Feature
    [Arguments]    ${feature}
    [Documentation]    Attaches Allure feature to the test.
    Run Keyword    allure.Attach    ${feature}    Feature    allure.attachment_type.TEXT

Attach Allure Story
    [Arguments]    ${story}
    [Documentation]    Attaches Allure story to the test.
    Run Keyword    allure.Attach    ${story}    Story    allure.attachment_type.TEXT

Attach Allure Severity
    [Arguments]    ${severity}
    [Documentation]    Attaches Allure severity to the test.
    Run Keyword    allure.Attach    ${severity}    Severity    allure.attachment_type.TEXT

Attach Allure Step
    [Arguments]    ${step}
    [Documentation]    Attaches Allure step to the test.
    Run Keyword    allure.Attach    ${step}    Step    allure.attachment_type.TEXT