import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

CSV_PATH = "./irn_results.csv"
MAX_IRNS = 10
COUNTRY = "UNITED KINGDOM"
ACTIVITY = "QC Review"
USERNAME = "ECUResolver1"
PASSWORD = "Sysadmin@123"
LOGIN_URL = "https://finato-uat.i-processmanager.com/IPMV4/Login/"

# Locators (from your .robot files)
username_field = (By.XPATH, "//input[@id='User_Name']")
password_field = (By.XPATH, "//input[@id='User_Password']")
loginbtn = (By.XPATH, "//input[@id='login']")
field_login_continue = (By.XPATH, "//*[@id='authenticate']/div/div/div")
checkbox_continue_login = (By.XPATH, "//*[@id='choice1']")
button_submit_continue = (By.XPATH, "//*[@id='btnSubmit']")
inbox_link = (By.XPATH, "//a[.//span[text()='Inbox']]")
activity_dropdown = (By.XPATH, "//label[normalize-space()='Activity']/following-sibling::span[@role='listbox']")
country_dropdown = (By.XPATH, "//label[normalize-space()='Country']/following-sibling::span[@role='listbox']")
irn_filter = (By.XPATH, "//tr[1]/th[3]/a[text()='IRN']")
recent_irn = (By.XPATH, "//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/a")
irn_table_first = (By.XPATH, "(//table[@id='irnTable']//tr/td[1])[1]")

def setup_driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    wait = WebDriverWait(driver, 20)
    return driver, wait

def click_continue_login(driver, wait):
    try:
        elem = wait.until(EC.visibility_of_element_located(field_login_continue))
        if elem.is_displayed():
            driver.find_element(*checkbox_continue_login).click()
            driver.find_element(*button_submit_continue).click()
    except TimeoutException:
        pass

def login(driver, wait):
    driver.get(LOGIN_URL)
    wait.until(EC.visibility_of_element_located(username_field)).send_keys(USERNAME)
    driver.find_element(*password_field).send_keys(PASSWORD)
    driver.find_element(*loginbtn).click()
    click_continue_login(driver, wait)
    try:
        wait.until(EC.presence_of_element_located((By.XPATH, "//h1[text()='Activity Matrix']")))
    except TimeoutException:
        print("Login Failed or Matrix Page didn't load")
        driver.quit()
        exit(1)

def navigate_to_inbox(driver, wait):
    wait.until(EC.element_to_be_clickable(inbox_link)).click()
    time.sleep(2)

def filter_country_and_activity(driver, wait):
    # Activity
    wait.until(EC.element_to_be_clickable(activity_dropdown))
    act_elem = driver.find_element(*activity_dropdown)
    driver.execute_script("arguments[0].scrollIntoView(true);", act_elem)
    act_elem.click()
    time.sleep(1)
    act_option = wait.until(EC.element_to_be_clickable((By.XPATH, f"//ul[contains(@id, 'selectActivityCode_listbox')]//li[normalize-space()='{ACTIVITY}']")))
    act_option.click()
    time.sleep(1)
    # Country
    wait.until(EC.element_to_be_clickable(country_dropdown))
    country_elem = driver.find_element(*country_dropdown)
    driver.execute_script("arguments[0].scrollIntoView(true);", country_elem)
    country_elem.click()
    time.sleep(1)
    country_option = wait.until(EC.element_to_be_clickable((By.XPATH, f"//ul[contains(@id, 'selectPlant_listbox')]//li[contains(text(), '{COUNTRY}')]")))
    country_option.click()
    time.sleep(1)

def click_irn_filter(driver, wait):
    wait.until(EC.visibility_of_element_located(irn_filter)).click()
    time.sleep(1)
    wait.until(EC.visibility_of_element_located(irn_filter)).click()
    time.sleep(1)

def get_latest_irn(driver, wait):
    wait.until(EC.visibility_of_element_located(recent_irn)).click()
    irn = wait.until(EC.visibility_of_element_located(irn_table_first)).text
    return irn

def submit_irn_for_matching(driver, wait, irn):
    try:
        wait.until(EC.element_to_be_clickable((By.XPATH, f"//td[text()='{irn}']"))).click()
        wait.until(EC.visibility_of_element_located((By.XPATH, "//label[contains(text(),'Select Activity Name')]/following-sibling::span[@role='listbox']"))).click()
        wait.until(EC.visibility_of_element_located((By.XPATH, "//ul[contains(@id,'Activity_Code_listbox')]//li[normalize-space()='Send For Match']"))).click()
        driver.find_element(By.ID, "Update2").click()
        status = WebDriverWait(driver, 5).until(
            EC.text_to_be_present_in_element((By.ID, "statusMessage"), "Submitted")
        )
        if status:
            return [irn, "submitted", ""]
        else:
            error_msg = driver.find_element(By.ID, "errorMessage").text
            return [irn, "not submitted", error_msg]
    except Exception as e:
        return [irn, "not submitted", str(e)]

def create_or_open_csv(path):
    try:
        with open(path, "x") as f:
            f.write("IRN,Status,Error Message\n")
    except FileExistsError:
        pass

def main():
    driver, wait = setup_driver()
    try:
        create_or_open_csv(CSV_PATH)
        login(driver, wait)
        navigate_to_inbox(driver, wait)
        filter_country_and_activity(driver, wait)
        click_irn_filter(driver, wait)

        results = []
        processed_count = 0
        for _ in range(MAX_IRNS):
            irn = get_latest_irn(driver, wait)
            result = submit_irn_for_matching(driver, wait, irn)
            results.append(result)
            processed_count += 1
            if processed_count >= MAX_IRNS:
                break
            # Optionally, refresh or re-filter if needed
            driver.refresh()
            time.sleep(2)
            filter_country_and_activity(driver, wait)
            click_irn_filter(driver, wait)

        df = pd.DataFrame(results, columns=["IRN", "Status", "Error Message"])
        df.to_csv(CSV_PATH, mode="a", header=False, index=False)
        print("=== IRN Submission Completed ===")
    finally:
        driver.quit()

if __name__ == "__main__":
    main()