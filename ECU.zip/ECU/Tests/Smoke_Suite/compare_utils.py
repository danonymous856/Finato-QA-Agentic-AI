import re
import copy
from robot.libraries.BuiltIn import BuiltIn


def clean_bl(value):
    return re.sub(r'[^A-Z0-9]', '', value.upper()) if value else ''


def is_within_tolerance(inv_val, est_val, tolerance=5.0):
    try:
        inv_str = str(inv_val).replace(',', '').strip()
        est_str = str(est_val).replace(',', '').strip()
        inv = float(inv_str)
        est = float(est_str)
        return abs(inv - est) <= tolerance
    except ValueError:
        return False


def normalize_dict_keys(data_list):
    normalized_list = []
    for row in data_list:
        normalized_row = {}
        for k, v in row.items():
            normalized_key = k.strip().lower().replace(" ", "_")
            normalized_row[normalized_key] = v
        normalized_list.append(normalized_row)
    return normalized_list


def log(msg, color=None):
    if color:
        BuiltIn().log(f"<span style='color:{color}'>{msg}</span>", html=True)
    else:
        BuiltIn().log_to_console(msg)


def log_comparison_result(results, best_only=False, section_title=None):
    log(f"[DEBUG] Calling log_comparison_result with best_only={best_only}, section_title={section_title}",
        color='purple')
    if section_title is None:
        section = "[ TOP MATCHES ]" if best_only else "[ ALL COMPARISONS ]"
    else:
        section = section_title
    log("\n" + section.center(60, "=") + "\n")

    for row_result in results:
        inv_row = row_result.get("invoice_row", "?")
        est_row = row_result.get("estimate_row", "?")
        is_aggregated = row_result.get("is_aggregated", False)

        if is_aggregated:
            log(f"[>] COMPARING INVOICE ROW(S) {inv_row} :: ESTIMATE ROW(S) {est_row}")
        else:
            log(f"[>] COMPARING INVOICE ROW {inv_row} :: ESTIMATE ROW {est_row}")
        log("-" * 60)

        # Log matched parameters
        log("[ MATCHED PARAMETERS ]")
        for match in row_result.get("matches", []):
            if match.get("skipped", False):
                continue
            key = match["key"].upper().replace(" ", "_")
            inv_val = match["invoice"]
            est_val = match["estimate"]

            if match["match"]:
                status = "[MATCH]"
                msg = match.get("msg", "")
                if key == "BL_MATCH":
                    inv_source = match.get("invoice_source", "")
                    est_source = match.get("estimate_source", "")
                    inv_display = f"{inv_source}='{inv_val}'" if inv_source else f"'{inv_val}'"
                    est_display = f"{est_source}='{est_val}'" if est_source else f"'{est_val}'"
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE({inv_display}) | ESTIMATE({est_display}){msg}")
                else:
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE='{inv_val}' | ESTIMATE='{est_val}'{msg}")

        # Log mismatched parameters
        log("\n" + "[ MISMATCHED PARAMETERS ]")
        for match in row_result.get("matches", []):
            if match.get("skipped", False):
                continue
            key = match["key"].upper().replace(" ", "_")
            inv_val = match["invoice"]
            est_val = match["estimate"]

            if not match["match"]:
                status = "[MISMATCH]"
                msg = match.get("msg", "")
                tolerance_msg = ""
                if key == "LINE_AMOUNT" and "tolerance_status" in match:
                    tolerance_msg = f" | ({match['tolerance_status']})"
                if key == "BL_MATCH":
                    inv_source = match.get("invoice_source", "")
                    est_source = match.get("estimate_source", "")
                    inv_display = f"{inv_source}='{inv_val}'" if inv_source else f"'{inv_val}'"
                    est_display = f"{est_source}='{est_val}'" if est_source else f"'{est_val}'"
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE({inv_display}) | ESTIMATE({est_display}){msg}{tolerance_msg}")
                else:
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE='{inv_val}' | ESTIMATE='{est_val}'{msg}{tolerance_msg}")

        log("-" * 60)
        score = f"{row_result.get('match_count', 0)} / {row_result.get('total', 0)}"
        total = row_result.get('total', 0)
        percent = round((row_result.get("match_count", 0) / total) * 100, 1) if total > 0 else 0
        log(f"[>] MATCH SCORE: {score}    | ACCURACY: {percent}%")

        if best_only or is_aggregated:
            expected = row_result.get("expected_status", "")
            actual = row_result.get("actual_status", "")
            valid = row_result.get("finato_validated", False)
            log(f"[>] FINATO STATUS CHECK   | EXPECTED='{expected}' | ACTUAL='{actual}' | VALID={valid}")
            if not expected == actual:
                log("matching failed ")
            log(f"")

        log("=" * 60)
        log("")


def compare_invoice_and_estimate_rows(invoice_data, estimate_data):
    invoice_data = normalize_dict_keys(invoice_data)
    estimate_data = normalize_dict_keys(estimate_data)

    all_comparisons = []
    best_matches = []
    top_matches_dict = {}

    primary_keys = [
        "sequence_number", "bl_match",
        "booking_number", "truck_number", "file_number",
    ]

    secondary_keys = ["currency", "line_amount"]

    key_map = {
        "association_id": "association_id",
        "sequence_number": "sequence_number",
        "currency": "currency",
        "line_amount": "amount",
        "file_number": "file_number",
        "file_number(from_file_details)": "file_number",
        "item_description":"description",
        "truck_number": "truck_number",
        "booking_number": "booking_number",
    }

    invoice_bl_keys = [
        "bl_number",
        "bl_number(from_file_details)",
        "container_number",
        "container_number(from_file_details)",
        "ocean_bl",
    ]
    estimate_bl_keys = [
        "bl_number",
        "transhipment_bl_number"
    ]

    for i, inv in enumerate(invoice_data):
        best_result = None
        best_match_count = -1
        best_total = 0

        for j, est in enumerate(estimate_data):
            row_result = {
                "invoice_row": i + 1,
                "estimate_row": j + 1,
                "matches": [],
                "match_count": 0,
                "total": 0
            }

            # Check ASSOCIATION_ID
            inv_assoc = inv.get("association_id", "").strip()
            est_assoc = est.get("association_id", "").strip()
            if inv_assoc != est_assoc:
                log(f"[SKIPPED] Association ID mismatch. Invoice='{inv_assoc}' | Estimate='{est_assoc}'",
                    color='orange')
                row_result["matches"].append(
                    {"key": "association_id", "invoice": inv_assoc, "estimate": est_assoc, "match": False,
                     "skipped": True})
                all_comparisons.append(row_result)
                continue
            else:
                row_result["matches"].append(
                    {"key": "association_id", "invoice": inv_assoc, "estimate": est_assoc, "match": True})
                row_result["total"] += 1
                row_result["match_count"] += 1

            # Step 2: Primary key check
            bl_match_found = False
            for key in primary_keys:
                if key == "bl_match":
                    bl_match = False
                    inv_bl_val = ""
                    est_bl_val = ""
                    inv_source = ""
                    est_source = ""
                    for inv_key in invoice_bl_keys:
                        for est_key in estimate_bl_keys:
                            inv_bl = inv.get(inv_key, "").strip()
                            est_bl = est.get(est_key, "").strip()
                            if clean_bl(inv_bl) and clean_bl(est_bl) and clean_bl(inv_bl) == clean_bl(est_bl):
                                bl_match = True
                                inv_bl_val = inv_bl
                                est_bl_val = est_bl
                                inv_source = inv_key
                                est_source = est_key
                                bl_match_found = True
                                break
                        if bl_match:
                            break

                    if not inv_bl_val:
                        inv_bl_val = next((inv.get(k, "") for k in invoice_bl_keys if inv.get(k)), "")
                        inv_source = next((k for k in invoice_bl_keys if inv.get(k)), "")
                    if not est_bl_val:
                        est_bl_val = next((est.get(k, "") for k in estimate_bl_keys if est.get(k)), "")
                        est_source = next((k for k in estimate_bl_keys if est.get(k)), "")

                    row_result["matches"].append({
                        "key": "bl_match",
                        "invoice": inv_bl_val,
                        "estimate": est_bl_val,
                        "match": bl_match,
                        "invoice_source": inv_source,
                        "estimate_source": est_source
                    })
                    if bl_match:
                        row_result["total"] += 1
                        row_result["match_count"] += 1
                    else:
                        row_result["total"] += 1
                    if not bl_match:
                        log(f"[SKIPPED] BL Match failed. Invoice({inv_source})='{inv_bl_val}' | Estimate({est_source})='{est_bl_val}'",
                            color='red')
                else:
                    inv_val = inv.get(key, "").strip()
                    est_val = est.get(key, "").strip()
                    match = inv_val == est_val

                    if inv_val in ['0', '']:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": False, "skipped": True})
                    else:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                    if not match and key != "sequence_number":
                        log(f"[SKIPPED] Primary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                            color='red')

            # Step 3: Secondary key check
            if bl_match_found:
                for key in secondary_keys:
                    inv_val = inv.get(key, "").strip()
                    est_key = key_map[key]
                    est_val = est.get(est_key, "").strip()

                    if inv_val in ['0', '']:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": False, "skipped": True})
                    else:
                        if key == "line_amount":
                            currency = inv.get("currency", "").strip().upper()
                            est_val = est_val if currency == "GBP" else est.get("line_amount(quantity*expprice)",
                                                                                "").strip()
                            match = is_within_tolerance(inv_val, est_val)
                            tolerance_status = ""
                            if not match:
                                try:
                                    inv_num = float(inv_val.replace(',', ''))
                                    est_num = float(est_val.replace(',', ''))
                                    if abs(inv_num - est_num) <= 5.0:
                                        tolerance_status = "under tolerance"
                                    else:
                                        tolerance_status = "out of tolerance"
                                except ValueError:
                                    tolerance_status = "invalid number format"
                        else:
                            match = inv_val == est_val
                            tolerance_status = ""

                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match,
                             "tolerance_status": tolerance_status})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                    if not match and key != "line_amount":
                        log(f"[SKIPPED] Secondary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                            color='red')

            all_comparisons.append(row_result)

            if row_result["match_count"] > best_match_count:
                best_result = row_result
                best_match_count = row_result["match_count"]
                best_total = row_result["total"]

        if best_result and best_match_count > 0:
            expected_status = "Matched" if best_match_count == best_total else "Estimates Mismatch"
            actual_status = inv.get("finato_matching_status", "").strip()
            best_result["expected_status"] = expected_status
            best_result["actual_status"] = actual_status
            best_result["finato_validated"] = (expected_status == actual_status)
            best_matches.append(best_result)
            top_matches_dict[(best_result["invoice_row"], best_result["estimate_row"])] = best_result
        else:
            log(f"[SKIPPED] No valid match found for Invoice Row {i + 1}", color='orange')
            best_matches.append({
                "invoice_row": i + 1,
                "estimate_row": "-",
                "matches": [],
                "match_count": 0,
                "total": 0,
                "expected_status": "Estimates Mismatch",
                "actual_status": inv.get("finato_matching_status", "").strip(),
                "finato_validated": False
            })

    # Aggregation Filter: Support many-to-many matching
    # Group invoices by association_id, currency, and bl_match
    invoice_groups = {}
    for i, inv in enumerate(invoice_data):
        assoc_id = inv.get("association_id", "").strip()
        currency = inv.get("currency", "").strip().upper()
        bl_val = ""
        bl_source = ""
        for inv_key in invoice_bl_keys:
            if inv.get(inv_key, "").strip():
                bl_val = inv.get(inv_key, "").strip()
                bl_source = inv_key
                break
        if not bl_val:
            continue
        group_key = (assoc_id, currency, clean_bl(bl_val))
        if group_key not in invoice_groups:
            invoice_groups[group_key] = {
                "invoice_rows": [],
                "line_amounts": [],
                "bl_val": bl_val,
                "bl_source": bl_source
            }
        invoice_groups[group_key]["invoice_rows"].append(i + 1)
        invoice_groups[group_key]["line_amounts"].append(inv.get("line_amount", "0").strip())

    # Group estimates by association_id, currency, and bl_match
    estimate_groups = {}
    for j, est in enumerate(estimate_data):
        assoc_id = est.get("association_id", "").strip()
        currency = est.get("currency", "").strip().upper()
        bl_val = ""
        bl_source = ""
        for est_key in estimate_bl_keys:
            if est.get(est_key, "").strip():
                bl_val = est.get(est_key, "").strip()
                bl_source = est_key
                break
        if not bl_val:
            continue
        group_key = (assoc_id, currency, clean_bl(bl_val))
        if group_key not in estimate_groups:
            estimate_groups[group_key] = {
                "estimate_rows": [],
                "line_amounts": [],
                "bl_val": bl_val,
                "bl_source": bl_source
            }
        estimate_groups[group_key]["estimate_rows"].append(j + 1)
        est_line_amount = est.get(key_map["line_amount"], "0").strip()
        if currency == "GBP":
            estimate_groups[group_key]["line_amounts"].append(est_line_amount)
        else:
            estimate_groups[group_key]["line_amounts"].append(est.get("line_amount(quantity*expprice)", "0").strip())

    # Process Aggregated Matches
    aggregated_matches = []
    aggregated_invoice_rows = set()
    aggregated_estimate_rows = set()
    for group_key in set(invoice_groups.keys()) & set(estimate_groups.keys()):
        inv_group = invoice_groups[group_key]
        est_group = estimate_groups[group_key]
        # Only aggregate if there are multiple rows in either invoices or estimates
        if len(inv_group["invoice_rows"]) > 1 or len(est_group["estimate_rows"]) > 1:
            inv_rows_str = ",".join(str(r) for r in sorted(inv_group["invoice_rows"]))
            est_rows_str = ",".join(str(r) for r in sorted(est_group["estimate_rows"]))
            summed_inv_amount = sum(float(amt.replace(',', '')) for amt in inv_group["line_amounts"] if amt)
            summed_est_amount = sum(float(amt.replace(',', '')) for amt in est_group["line_amounts"] if amt)
            line_amount_match = is_within_tolerance(summed_inv_amount, summed_est_amount)
            tolerance_status = ""
            if not line_amount_match:
                try:
                    if abs(summed_inv_amount - summed_est_amount) <= 5.0:
                        tolerance_status = "under tolerance"
                    else:
                        tolerance_status = "out of tolerance"
                except ValueError:
                    tolerance_status = "invalid number format"

            # Create matches for aggregated result
            matches = [
                {
                    "key": "association_id",
                    "invoice": group_key[0],
                    "estimate": group_key[0],
                    "match": True
                },
                {
                    "key": "bl_match",
                    "invoice": inv_group["bl_val"],
                    "estimate": est_group["bl_val"],
                    "match": True,
                    "invoice_source": inv_group["bl_source"],
                    "estimate_source": est_group["bl_source"]
                },
                {
                    "key": "currency",
                    "invoice": group_key[1],
                    "estimate": group_key[1],
                    "match": True
                },
                {
                    "key": "line_amount",
                    "invoice": str(summed_inv_amount),
                    "estimate": str(summed_est_amount),
                    "match": line_amount_match,
                    "msg": " | Aggregated",
                    "tolerance_status": tolerance_status
                }
            ]

            # Create aggregated result
            match_count = sum(1 for m in matches if m["match"])
            total = len([m for m in matches if not m.get("skipped", False)])
            aggregated_result = {
                "invoice_row": inv_rows_str,
                "estimate_row": est_rows_str,
                "matches": matches,
                "match_count": match_count,
                "total": total,
                "is_aggregated": True,
                "expected_status": "Matched" if match_count == total else "Estimates Mismatch",
                "actual_status": invoice_data[inv_group["invoice_rows"][0] - 1].get("finato_matching_status", "").strip(),
                "finato_validated": match_count == total and invoice_data[inv_group["invoice_rows"][0] - 1].get("finato_matching_status", "").strip() == "Matched"
            }
            aggregated_matches.append(aggregated_result)
            aggregated_invoice_rows.update(inv_group["invoice_rows"])
            aggregated_estimate_rows.update(est_group["estimate_rows"])

            # Log aggregation notice
            log(f"[DEBUG] Aggregation required between [INVOICE ROWS {inv_rows_str} :: ESTIMATE ROWS {est_rows_str}]",
                color='blue')

    # Dynamic FILTERED TOP MATCHES: Include best match for each invoice row
    filtered_top_matches = []
    matched_invoice_rows = set()
    for inv_row in range(1, len(invoice_data) + 1):
        # Find the best match for this invoice row, including invalid matches
        best_match = next((m for m in best_matches if m["invoice_row"] == inv_row), None)
        if best_match and best_match["estimate_row"] != "-":
            if best_match["invoice_row"] not in aggregated_invoice_rows and best_match["estimate_row"] not in aggregated_estimate_rows:
                filtered_top_matches.append(best_match)
                matched_invoice_rows.add(inv_row)
        elif best_match:  # No valid estimate match (estimate_row == "-")
            filtered_top_matches.append(best_match)
            matched_invoice_rows.add(inv_row)

    # Include aggregated matches
    if aggregated_matches:
        filtered_top_matches.extend(aggregated_matches)
        matched_invoice_rows.update(
            int(row) for m in aggregated_matches for row in m["invoice_row"].split(",")
        )

    # Check for unmatched invoice rows
    for inv_row in range(1, len(invoice_data) + 1):
        if inv_row not in matched_invoice_rows:
            log(f"[ERROR] No match found for Invoice Row {inv_row}", color='red')
            filtered_top_matches.append({
                "invoice_row": inv_row,
                "estimate_row": "-",
                "matches": [],
                "match_count": 0,
                "total": 0,
                "expected_status": "Estimates Mismatch",
                "actual_status": invoice_data[inv_row - 1].get("finato_matching_status", "").strip(),
                "finato_validated": False
            })

    # Log TOP MATCHES
    log_comparison_result(best_matches, best_only=True, section_title="[ TOP MATCHES ]")

    # Log AGGREGATED COMPARISONS
    if aggregated_matches:
        log_comparison_result(aggregated_matches, best_only=True, section_title="[ AGGREGATED COMPARISONS ]")

    # Log FILTERED TOP MATCHES
    log_comparison_result(filtered_top_matches, best_only=True, section_title="[ FINAL RESULTS ]")

    # Validate filtered matches
    all_valid = all(r.get("finato_validated", True) for r in filtered_top_matches)
    if not all_valid:
        BuiltIn().fail("One or more FINATO matches failed validation!")

    return filtered_top_matches, all_comparisons