*** Settings ***
Library    SeleniumLibrary
Library    BuiltIn
Library    String
Library    XML
Resource   ../../Resources/Keywords/Global_Keywords.robot
Resource   ../../Resources/Pages/LoginPage.robot
Resource   ../../Resources/Pages/HomePage.robot
Resource   ../../Resources/Pages/InboxPage.robot
Resource   ../../Resources/Pages/InvoiceTranscationDetailPage.robot

*** Variables ***
${URL}       https://finato-uat.i-processmanager.com/IPMV4/Login/
${BROWSER}   chrome
${TARGET_IRN}    732

*** Test Cases ***
Match Invoice To Estimate
    [Documentation]    Full flow to match invoice and estimate using BL, currency, and amount.
    Open Browser To Login Page
    Enter Login Credentials
    Click Matched Local Count
    Click on IRN filter to filter the recent IRN
    Click on latest IRN
    Click Matching Icon
    Perform Invoice Matching
    Close Browser

*** Keywords ***
Enter Login Credentials
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}   ${VALID USERNAME}
    Input Text    ${password_field}   ${VALID PASSWORD}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']  timeout=10s

Click Matched Local Count
    Wait Until Element Is Visible    xpath=//a[@href and contains(@href, 'DocSubType=Local') and contains(@href, 'ActivityCode=MAT')]    timeout=10s
    Click Element    xpath=//a[@href and contains(@href, 'DocSubType=Local') and contains(@href, 'ActivityCode=MAT')]

Click on IRN filter to filter the recent IRN
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}

Click on latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}
    ${irn}=    Get Text    ${Recent_IRN}
    Log    Clicked on IRN: ${irn}
    Click Element    ${Recent_IRN}
    Wait Until Element Is Visible    ${InvoiceNumber}    timeout=10s

Wait Until Number Of Windows Is
    [Arguments]    ${expected}=2    ${timeout}=10s
    Wait Until Keyword Succeeds    ${timeout}    1s
    ...    Run Keyword And Return Status    Check Window Count    ${expected}

Check Window Count
    [Arguments]    ${expected}
    ${handles}=    Get Window Handles
    ${count}=      Get Length    ${handles}
    Should Be Equal As Integers    ${count}    ${expected}

Click Matching Icon
    [Documentation]    Clicks Matching icon, waits for new tab, switches to it, waits for invoice table to load, then matches.
    ${before}=    Get Window Handles
    ${before_count}=    Get Length    ${before}
    Click Element    xpath=//a[@id='btnMatching']
    Log    clicked on matching button
    Wait Until Number Of Windows Is   ${before_count + 1}
    Switch Window   NEW
    Wait Until Element Is Visible    xpath=//div[@id='polineitemGrid']    timeout=15s
    Log    Estimate section is loaded successfully

Perform Invoice Matching
    [Documentation]     Matches each invoice line with all estimate lines based on BL, currency, and amount.
    Wait Until Page Contains Element    xpath=//td[@data-field='InvoiceLineAmountWithTax']    timeout=10s
    ${invoice_row_count}    SeleniumLibrary.Get Element Count    xpath=//div[@id='invoicelineitemGrid']//tbody/tr
    ${estimate_row_count}   SeleniumLibrary.Get Element Count    xpath=//div[@id='polineitemGrid']//tbody/tr

    # Ensure tables are not empty
    Run Keyword If    ${invoice_row_count} == 0    Fail    Invoice table is empty.
    Run Keyword If    ${estimate_row_count} == 0   Fail    Estimate table is empty.

    # Iterate over all invoice rows
    FOR    ${inv_index}    IN RANGE    1    ${invoice_row_count + 1}
        ${invoice_bl}         Get Text    xpath=//div[@id='invoicelineitemGrid']//tbody/tr[${inv_index}]/td[@data-field='PO_Number']
        ${invoice_currency}   Get Text    xpath=//div[@id='invoicelineitemGrid']//tbody/tr[${inv_index}]/td[@data-field='Currency']
        ${invoice_amount}     Get Text    xpath=//div[@id='invoicelineitemGrid']//tbody/tr[${inv_index}]/td[@data-field='InvoiceLineAmountWithTax']

        ${invoice_bl}         Strip String        ${invoice_bl}
        ${invoice_currency}   Strip String        ${invoice_currency}
        ${invoice_amount}     Convert To Number   ${invoice_amount}

        Log    ➤ Invoice Row ${inv_index} → BL: ${invoice_bl}, Currency: ${invoice_currency}, Amount: ${invoice_amount}

        ${matched}    Create List

        # Iterate over all estimate rows
        FOR    ${est_index}    IN RANGE    1    ${estimate_row_count + 1}
            ${est_bl}         Get Text    xpath=//div[@id='polineitemGrid']//tbody/tr[${est_index}]/td[@data-field='PONumber']
            ${est_currency}   Get Text    xpath=//div[@id='polineitemGrid']//tbody/tr[${est_index}]/td[@data-field='Currency']
            ${est_amount}     Get Text    xpath=//div[@id='polineitemGrid']//tbody/tr[${est_index}]/td[@data-field='PoLineFinalAmount']

            ${est_bl}         Strip String        ${est_bl}
            ${est_currency}   Strip String        ${est_currency}
            ${est_amount}     Convert To Number   ${est_amount}

            ${bl_match}       Run Keyword And Return Status    Should Be Equal  ${est_bl}  ${invoice_bl}
            ${currency_match}    Run Keyword And Return Status    Should Be Equal  ${est_currency}  ${invoice_currency}
            ${amount_match}   Run Keyword And Return Status    Should Be Equal As Numbers  ${est_amount}  ${invoice_amount}

            Log   ➤ Estimate Row ${est_index} → BL Match: ${bl_match}, Currency Match: ${currency_match}, Amount Match: ${amount_match}
            Log   ---------------------------------------

            Run Keyword If    ${bl_match} and ${currency_match} and ${amount_match}
            ...    Append To List    ${matched}    ${est_index}
        END

        Run Keyword If    ${matched}
        ...    Log    Invoice Row ${inv_index} has matched with estimate rows : ${matched}
        ...    ELSE
        ...    Log    No match found for Invoice Row ${inv_index}
        Log    --------------------------------------------
    END