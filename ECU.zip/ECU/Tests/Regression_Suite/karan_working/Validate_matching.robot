*** Settings ***
Library             SeleniumLibrary
Library             Process
Library             RPA.Excel.Files
Library             test.py

Resource            ../../../Resources/Keywords/Global_Keywords.robot
Resource            ../../../Resources/Pages/LoginPage.robot
Resource            ../../../Resources/Pages/HomePage.robot
Resource            ../../../Resources/Pages/InboxPage.robot
Resource            ../../../Resources/Pages/SearchPage.robot
Resource            ../../../Resources/Pages/InvoiceTranscationDetailPage.robot
Resource            ../../../Resources/Pages/MatchingScreenPage.robot


Suite Setup         Open Browser To Login Page
Suite Teardown      Close Browser


*** Test Cases ***
Validate Matching Logic
    [Tags]    Smoke    Regression
    Verify Matching Logic
#    [Teardown]    Log Matching Summary


*** Keywords ***
Verify Matching Logic
    [Documentation]    This keyword verifies the matching logic by performing the following steps:
    Enter Login Credentials    ${Resolver1}    ${VALID PASSWORD}
    Click Continue Login
    Click On Inbox Icon and Navigate to Inbox Page
    Select Plant
    Select Activity for filter records
    Click on IRN filter to filter the recent IRN
    Click on latest IRN
    Retrieve IRN and Store into Variable
#    Delete existing line Item
#    Sleep    2s
#    Add Line details
    Add header details
#    Select activity
#    Click on Submit Button
#    Close Invoice Transaction Detail Page
#    Logout from application
#    Enter Login Credentials    ${Auditor1}    ${VALID PASSWORD}
#    Click Continue Login
#    Navigate to Filter page
#    Search for IRN
#    Wait For Status Change Then Click IRN
#    Click Matching Icon
#    Extract Table Data As JSON
#    Match Invoice To Estimate

Enter Login Credentials
    [Arguments]    ${username}    ${password}
    Wait Until Element Is Visible    ${username_field}
    Input Text    ${username_field}    ${username}
    Input Text    ${password_field}    ${password}
    Click Element    ${loginbtn}
    Click Continue Login
    Wait Until Page Contains Element    //h1[text()='Activity Matrix']    timeout=10s

Click Continue Login
    Run Keyword And Ignore Error    Wait Until Element Is Visible    ${Feild_LoginContinue}    timeout=05s    error=False
    ${ContinueLogin}=    Is Element Visible   ${Feild_LoginContinue}
    IF    ${ContinueLogin} == True
        Click Element    ${CheckBox_Continue_Login}
        Click Element    ${button_Submit_Continue}
    END


Click QC Review Local Count
    Wait Until Element Is Visible    ${QC_REVIEW_LOCAL_COUNT}    timeout=10s
    Click Element    ${QC_REVIEW_LOCAL_COUNT}

Click On Inbox Icon and Navigate to Inbox Page
    Wait Until Element Is Visible    //span[@title='Inbox']    timeout=10s
    Click Element    //span[@title='Inbox']
    Wait Until Page Contains Element    //h1[normalize-space()='Inbox']    timeout=10s

Select Plant
    Wait Until Element Is Visible    //th[@class="k-header"]/following::a[text()='Action']  timeout=10s

    Click Element    //span[@aria-owns='selectPlant_listbox']//span[contains(@class,'k-select')]
    Wait Until Element Is Visible    //ul[@id='selectPlant_listbox' and @aria-hidden='false']    timeout=10s
    Wait for Element and Click    //ul[@id='selectPlant_listbox' and @aria-hidden='false']//li[normalize-space()='${country1}']
    Sleep    5s

Select Activity for filter records
    Click Element    //span[@aria-owns='selectActivityCode_listbox']//span[contains(@class,'k-select')]
    Wait Until Element Is Visible    //ul[@id='selectActivityCode_listbox' and @aria-hidden='false']    timeout=10s
    Wait Until Element Is Visible    //ul[@id='selectActivityCode_listbox' and @aria-hidden='false']    timeout=10s
    Sleep   1s    # Allow dropdown animation to finish
    Scroll Element Into View    //ul[@id='selectActivityCode_listbox' and @aria-hidden='false']//li[normalize-space()='${activity}']
    Sleep    0.3s    # Ensure element is stable
    Click Element    //ul[@id='selectActivityCode_listbox' and @aria-hidden='false']//li[normalize-space()='${activity}']
    Sleep    5s

Click on IRN filter to filter the recent IRN
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}
    Sleep    2s
    Wait Until Element Is Visible    ${IRN_Filter}
    Click Element    ${IRN_Filter}

Click on latest IRN
    Wait Until Element Is Visible    ${Recent_IRN}
    Click Element    ${Recent_IRN}
    Wait Until Element Is Visible    ${InvoiceNumber}    timeout=10s

Add header details
    Open Workbook    Resources/TestData/MatchingTestData.xlsx
    ${data}=    Read Worksheet    header=True
    ${header}=    Set Variable    ${data}[0]
#   Input and Click Slowly    ${Vendor_Name/Code}    1463417
     Input and Click Slowly With Correction    ${Vendor_Name/Code}    ${header}[vendor name]
#    Set Selenium Speed    0s
    Wait for element visible and input text    ${InvoiceNumber}    ${header}[invoice number]
    Date Picker    ${invoiceDate}    ${header}[invoice date]
    Wait for Element and Click    ${invoiceAmount}
    ${invoice_value}=    Get Element Attribute    ${InvoiceAmount_INPUT_FIELD}    value
    IF    '${invoice_value}' != '' and '${invoice_value}' != '${EMPTY}'
        Clear Element Text    ${InvoiceAmount_INPUT_FIELD}
        Click Element    ${invoiceAmount}
        Wait for Element and Input    ${InvoiceAmount_INPUT_FIELD}    ${header}[invoice amount]
    ELSE
        Wait for Element and Input    ${InvoiceAmount_INPUT_FIELD}    ${header}[invoice amount]
    END
    Wait for Element and Click    ${VAT_Field_Sibling}
    ${vat_value}=    Get Element Attribute    ${VAT_Field}    value
    IF    '${vat_value}' != '' and '${vat_value}' != '${EMPTY}'
        Clear Element Text    ${VAT_Field}
        Click Element    ${VAT_Field_Sibling}
        Wait for Element and Input    ${VAT_Field}    ${header}[vat value]
    ELSE
        Wait for Element and Input    ${VAT_Field}    ${header}[vat value]
    END
    Wait for Element and Click    ${Currency_Suggesionbox}
    Clear Element Text    ${Currency_Suggesionbox}
    Wait for Element and Input    ${Currency_Suggesionbox}    ${header}[currency value]
    Wait for Element and Click    ${Select_Currency}
    Clear Element Text    ${Invoice_ref_number}
    Wait for Element and Input    ${Invoice_ref_number}    ${header}[invoice ref number]
    Wait for Element and Click    ${ExchangeRate_Sibling}
    ${exchange_rate_value}=    Get Element Attribute    //input[@id="FileSaveExchange_Rate"]    value
    IF    '${exchange_rate_value}' != '' and '${exchange_rate_value}' != '${EMPTY}'
        Clear Element Text    ${ExchangeRate}
        Wait Until Element Is Visible    ${ExchangeRateError}
        Click Element    ${ExchangeRate_Sibling}
        Press Keys    ${ExchangeRate}    ${header}[exchange rate]
    ELSE
        Press Keys    ${ExchangeRate}    ${header}[exchange rate]
    END
    Sleep    2s
    Scroll Element Into View    ${Activity_Code_Dropdown}
    #import export
    Wait Until Element Is Visible    //input[@aria-owns='FileSaveImport_Export_Type_listbox' and contains(@class,'k-input')]    timeout=10s
    Input Text    //input[@aria-owns='FileSaveImport_Export_Type_listbox' and contains(@class,'k-input')]    Import
    Wait Until Element Is Visible    //ul[@id='FileSaveImport_Export_Type_listbox' and @aria-hidden='false']    timeout=10s
    Click Element    //ul[@id='FileSaveImport_Export_Type_listbox' and @aria-hidden='false']//li[normalize-space()='Import']

    Close Workbook

Delete existing line Item
    ${Checkbox_present}=    Run Keyword And Return Status    Wait Until Element Is Visible    ${IsCheckBox_Present}    timeout=10s
    IF    ${Checkbox_present}
        Click Element    ${ActionCheckBox}
        Wait Until Element Is Visible    ${deleteButton}
        Click Element    ${deleteButton}
        Click Element    ${ConfirmDeletePopup}
        Sleep    5s
    END
Click On Add Button
    Wait Until Element Is Visible    ${Add_Button}
    Click Element    ${Add_Button}
    Sleep    5s
Add Line details
    Open Workbook    Resources/TestData/MatchingTestData.xlsx
    ${data}=    Read Worksheet    header=True
    ${test_case}=    Set Variable    TC01  # Replace dynamically if needed
    FOR    ${row}    IN    @{data}
        ${row_test_case}=    Set Variable    ${row}[Test Case]
        Run Keyword If    '${row_test_case}' == '${test_case}'    Add Single Line Item    ${row}

    END
    Close Workbook

Add Single Line Item
    [Arguments]    ${line}

    Click On Add Button

    Wait Until Element Is Visible    ${Sequence Number}    timeout=10s
    Input Text    ${Sequence Number}    ${line}[sequence number]
    Wait Until Element Is Visible    ${Container Number}    timeout=10s
    Input Text    ${Container Number}    ${line}[container number]

    Wait Until Element Is Visible    ${Booking Number}    timeout=10s
    Input Text    ${Booking Number}    ${line}[booking number]

    Wait Until Element Is Visible    ${BL Number}    timeout=10s
    Input Text    ${BL Number}    ${line}[bl number]

    Wait Until Element Is Visible    ${OBL / MBL Number}    timeout=10s
    Input Text    ${OBL / MBL Number}    ${line}[obl / mbl number]

    Wait Until Element Is Visible    ${File Number}    timeout=10s
    Input Text    ${File Number}    ${line}[file number]

    Wait Until Element Is Visible    ${Truck Number}    timeout=10s
    Input Text    ${Truck Number}    ${line}[truck number]

    Wait Until Element Is Visible    ${Item Description}    timeout=10s
    Input Text    ${Item Description}    ${line}[item description]

    Wait Until Element Is Visible    ${Currency}    timeout=10s
    Input Text    ${Currency}    ${line}[currency]

    Wait Until Element Is Visible    //ul[@id='FileSaveCurrency_listbox' and @aria-hidden='false']    timeout=10s
    Click Element    //ul[@id='FileSaveCurrency_listbox' and @aria-hidden='false']

    Wait Until Element Is Visible    ${Quantity}    timeout=10s
    Input Text    ${Quantity}    ${line}[quantity]

    # REMOVED --> Wait for Element and Click    ${NUMERIC_WRAP} (caused error, not needed)

    Wait Until Element Is Visible    ${Unit Price Visible}    timeout=10s
    Input Text    ${Unit Price Visible}    ${line}[unit price]

    Wait Until Element Is Visible    ${Rate}    timeout=10s
    Input Text    ${Rate}    ${line}[rate]

    Wait Until Element Is Visible    ${VAT Tax Percentage}    timeout=10s
    Input Text    ${VAT Tax Percentage}    ${line}[vat tax percentage]
    Wait Until Element Is Visible    ${Amount(HC)}    timeout=10s
    Input Text    ${Amount(HC)}    ${line}[amount hc]
    Click Element    ${Save_Button}
    Sleep    2s


Select activity
    Scroll Element Into View    ${Activity_Code_Dropdown}
    Wait Until Element Is Not Visible    //div[@class='transaction-modal-footer']    timeout=10s
    Wait Until Element Is Visible    ${Dropdown_Arrow}    timeout=10s
    Execute JavaScript    document.evaluate(`${Dropdown_Arrow}`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()
    Wait Until Element Is Visible    //li[text()='Send For Match']/ancestor::ul[@id="Activity_Code_listbox"]    timeout=10s
    Sleep    0.5s
    Click Element    //ul[@id="Activity_Code_listbox"]//li[@role="option"][normalize-space()="Send For Match"]
    Log To Console    Selected Activity: Send For Match
Click on Submit Button
    Wait for Element and Click    ${Submit}
    Log To Console    clicked on Submit Button

Close Invoice Transaction Detail Page
    Wait for Element and Click    (//a[@aria-label='Close'])[1]
    Log To Console    clicked on close button of Invoice Transaction Detail Page
Navigate to Filter page
    Click Element    //span[@title='Search']
    Wait Until Page Contains Element    xpath=//h6[text()='Filter']   timeout=10s
Search for IRN
    Wait Until Element Is Visible    //input[@id='txtdrn']
    Input Text      xpath=//input[@id='txtdrn']  ${Current_IRN}
    Click Element    ${SUBMIT_BUTTON}

Wait For Status Change Then Click IRN
    ${max_wait_time}=    Set Variable    60
    ${interval}=         Set Variable    1
    ${elapsed}=          Set Variable    0
    ${status_locator}=   Set Variable    //tr[@class="k-state-selected"]/td[@data-field="Activity_Code"]
    ${refresh_button}=   Set Variable    //a[@title="Refresh"]
    ${expected_1}=       Set Variable    Matched
    ${expected_2}=       Set Variable    Matching Exceptions

    WHILE    ${elapsed} < ${max_wait_time}
        Click Element    ${refresh_button}
        Sleep    ${interval}
        ${status}=    Get Text    ${status_locator}
        Log    Current Status: ${status}
        Run Keyword If    '${status}' == '${expected_1}' or '${status}' == '${expected_2}'    Exit For Loop
        ${elapsed}=    Evaluate    ${elapsed} + ${interval}
    END

    Run Keyword If    '${status}' != '${expected_1}' and '${status}' != '${expected_2}'    Fail    Status did not change to expected value in time
    Click Element    //td[@data-field="drn"]/a
    Wait Until Element Is Visible    ${InvoiceNumber}    timeout=10s
##########################################################################################

Click Matching Icon
    [Documentation]    Clicks Matching icon, waits for new tab, switches to it, waits for invoice table to load, then matches.
    ${before}=    Get Window Handles
    ${before_count}=    Get Length    ${before}
    Click Element    xpath=//a[@id='btnMatching']
    Log    clicked on matching button
    Wait Until Number Of Windows Is   ${before_count + 1}
    Switch Window   NEW
    Wait Until Element Is Visible    xpath=//div[@id='polineitemGrid']    timeout=15s
    Log    Estimate section is loaded successfully

Extract Table Data As JSON
    [Documentation]    Extracts invoice and estimate table data as JSON dictionaries using headers for row-wise mapping.
    Wait Until Element Is Visible    ${INVOICE_FIRST_ROW_XPATH}    timeout=15s
    Wait Until Element Is Visible    ${ESTIMATE_FIRST_ROW_XPATH}    timeout=15s
    Sleep    1s

    ### INVOICE TABLE
    ${invoice_headers}=    Create List
    ${invoice_header_elements}=    Get WebElements    ${INVOICE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{invoice_header_elements}
        ${header}=    SeleniumLibrary.Get Element Attribute    ${header_el}    data-title
        Run Keyword If    '${header}' == '' or '${header}' == None    ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${invoice_headers}    ${header}
    END


    ${invoice_row_count}=    SeleniumLibrary.Get Element Count    ${INVOICE_ROWS_XPATH}
    ${invoice_data}=    Create List

    ${invoice_col_count}=    Get Length    ${invoice_headers}
    FOR    ${i}    IN RANGE    1    ${invoice_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${invoice_col_count + 1}
            ${row_str}=    Convert To String    ${i}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${INVOICE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${invoice_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
        END
        Append To List    ${invoice_data}    ${row}
    END

#    ${invoice_json}=    Evaluate    json.dumps(${invoice_data}, indent=2)    json
#    Log    INVOICE TABLE JSON:
#    Log    ${invoice_json}

    ### ESTIMATE TABLE
    ${estimate_headers}=    Create List
    ${estimate_header_elements}=    Get WebElements    ${ESTIMATE_HEADERS_XPATH}
    FOR    ${header_el}    IN    @{estimate_header_elements}
        ${header}=    Get Text    ${header_el}
        ${header}=    Convert To String    ${header}
        Append To List    ${estimate_headers}    ${header}
    END

    ${estimate_row_count}=    SeleniumLibrary.Get Element Count    ${ESTIMATE_ROWS_XPATH}
    ${estimate_data}=    Create List

    ${estimate_col_count}=    Get Length    ${estimate_headers}
    FOR    ${j}    IN RANGE    1    ${estimate_row_count + 1}
        ${row}=    Create Dictionary
        FOR    ${col_index}    IN RANGE    1    ${estimate_col_count + 1}
            ${row_str}=    Convert To String    ${j}
            ${col_str}=    Convert To String    ${col_index}
            ${cell_xpath}=    Replace String    ${ESTIMATE_CELL_XPATH_TEMPLATE}    {row}    ${row_str}
            ${cell_xpath}=    Replace String    ${cell_xpath}    {col}    ${col_str}
            ${value}=    Get Text    ${cell_xpath}
            ${key}=    Convert To String    ${estimate_headers[${col_index - 1}]}
            Run Keyword If    '${key}' == '' or '${key}' == None    Set Variable    ${key}    Column ${col_index}
            Set To Dictionary    ${row}    ${key}=${value}
            Set To Dictionary    ${row}    ${estimate_headers[${col_index - 1}]}=${value}
        END
        Append To List    ${estimate_data}    ${row}
    END

#    ${estimate_json}=    Evaluate    json.dumps(${estimate_data}, indent=2)    json
#    Log    ESTIMATE TABLE JSON:
#    Log    ${estimate_json}
#    Log To Console    ${invoice_json}
#    Log To Console    ${estimate_json}
    [Return]    ${invoice_data}    ${estimate_data}


Match Invoice To Estimate
    [Documentation]    Match invoice lines with estimates and validate using FINATO status

    ${invoice_data}    ${estimate_data}=
    ...    Extract Table Data As JSON

    ${best_results}    ${all_comparisons}=
    ...    Evaluate    test.compare_invoice_and_estimate_rows(${invoice_data}, ${estimate_data})    test
     Set Suite Variable   ${best_results}
    ### Log the best matching results for Allure ###
    Evaluate    test.log_comparison_result(${best_results}, best_only=True)    test
    Evaluate    test.log_full_match_summary(${best_results})    test

    ### Validate that all FINATO statuses are correct ###
    ${all_valid}=
    ...    Evaluate    all(r.get("finato_validated", True) for r in ${best_results})    test
    Should Be True    ${all_valid}    One or more FINATO matches failed validation!

Log matching summary
    Evaluate    test.log_full_match_summary(${best_results})    test

    ### Optional: Log result summary for debug clarity ###
#    Log    FINATO Validation Summary: ${best_results}

