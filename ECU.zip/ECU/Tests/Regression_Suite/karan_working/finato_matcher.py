import re
import copy
from robot.libraries.BuiltIn import BuiltIn


def clean_bl(value):
    return re.sub(r'[^A-Z0-9]', '', value.upper()) if value else ''


def is_within_tolerance(inv_val, est_val, tolerance=5.0):
    try:
        inv_str = str(inv_val).replace(',', '').strip()
        est_str = str(est_val).replace(',', '').strip()
        inv = float(inv_str)
        est = float(est_str)
        return abs(inv - est) <= tolerance
    except ValueError:
        return False


def normalize_dict_keys(data_list):
    normalized_list = []
    for row in data_list:
        normalized_row = {}
        for k, v in row.items():
            normalized_key = k.strip().lower().replace(" ", "_")
            normalized_row[normalized_key] = v
        normalized_list.append(normalized_row)
    return normalized_list


def log(msg, color=None):
    if color:
        BuiltIn().log(f"<span style='color:{color}'>{msg}</span>", html=True)
    else:
        BuiltIn().log_to_console(msg)


def log_comparison_result(results, best_only=False, section_title=None):
    log(f"[DEBUG] Calling log_comparison_result with best_only={best_only}, section_title={section_title}",
        color='purple')
    if section_title is None:
        section = "[ TOP MATCHES ]" if best_only else "[ ALL COMPARISONS ]"
    else:
        section = section_title
    log("\n" + section.center(60, "=") + "\n")

    for row_result in results:
        inv_row = row_result.get("invoice_row", "?")
        est_row = row_result.get("estimate_row", "?")
        is_aggregated = row_result.get("is_aggregated", False)

        if is_aggregated:
            log(f"[>] COMPARING INVOICE ROW {inv_row} :: ESTIMATE ROW {est_row}")
        else:
            log(f"[>] COMPARING INVOICE ROW {inv_row} :: ESTIMATE ROW {est_row}")
        log("-" * 60)

        log("[ MATCHED PARAMETERS ]")
        for match in row_result.get("matches", []):
            if match.get("skipped", False):
                continue
            key = match["key"].upper().replace(" ", "_")
            inv_val = match["invoice"]
            est_val = match["estimate"]

            if match["match"]:
                status = "[MATCH]"
                msg = match.get("msg", "")
                if key == "BL_MATCH":
                    inv_source = match.get("invoice_source", "")
                    est_source = match.get("estimate_source", "")
                    inv_display = f"{inv_source}='{inv_val}'" if inv_source else f"'{inv_val}'"
                    est_display = f"{est_source}='{est_val}'" if est_source else f"'{est_val}'"
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE({inv_display}) | ESTIMATE({est_display}){msg}")
                else:
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE='{inv_val}' | ESTIMATE='{est_val}'{msg}")

        log("\n" + "[ MISMATCHED PARAMETERS ]")
        for match in row_result.get("matches", []):
            if match.get("skipped", False):
                continue
            key = match["key"].upper().replace(" ", "_")
            inv_val = match["invoice"]
            est_val = match["estimate"]

            if not match["match"]:
                status = "[MISMATCH]"
                msg = f" | msg: {match.get('msg', '')}" if match.get("msg") else ""
                if key == "BL_MATCH":
                    inv_source = match.get("invoice_source", "")
                    est_source = match.get("estimate_source", "")
                    inv_display = f"{inv_source}='{inv_val}'" if inv_source else f"'{inv_val}'"
                    est_display = f"{est_source}='{est_val}'" if est_source else f"'{est_val}'"
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE({inv_display}) | ESTIMATE({est_display}){msg}")
                else:
                    log(f"[DEBUG] {key:<20}: {status:<10} | INVOICE='{inv_val}' | ESTIMATE='{est_val}'{msg}")

        log("-" * 60)
        score = f"{row_result.get('match_count', 0)} / {row_result.get('total', 0)}"
        total = row_result.get('total', 0)
        percent = round((row_result.get("match_count", 0) / total) * 100, 1) if total > 0 else 0
        log(f"[>] MATCH SCORE: {score}    | ACCURACY: {percent}%")

        if best_only or is_aggregated:
            expected = row_result.get("expected_status", "")
            actual = row_result.get("actual_status", "")
            valid = row_result.get("finato_validated", False)
            log(f"[>] FINATO STATUS CHECK   | EXPECTED='{expected}' | ACTUAL='{actual}' | VALID={valid}")
            if not expected == actual:
                log("matching failed ")
            log(f"")

        log("=" * 60)
        log("")


def compare_invoice_and_estimate_rows(invoice_data, estimate_data):
    invoice_data = normalize_dict_keys(invoice_data)
    estimate_data = normalize_dict_keys(estimate_data)

    all_comparisons = []
    best_matches = []
    top_matches_dict = {}

    primary_keys = [
        "sequence_number", "bl_match",
        "booking_number", "truck_number", "file_number",
        "ocean_bl", "file_number(from_file_details)"
    ]

    secondary_keys = ["currency", "line_amount"]

    key_map = {
        "association_id": "association_id",
        "sequence_number": "sequence_number",
        "currency": "currency",
        "line_amount": "amount",
        "file_number": "file_number",
        "item_description": "description"
    }

    invoice_bl_keys = [
        "bl_number",
        "bl_number(from_file_details)",
        "container_number",
        "container_number(from_file_details)"
    ]
    estimate_bl_keys = [
        "bl_number",
        "transhipment_bl_number"
    ]

    # Pre-processing: Check for duplicate estimates
    estimate_keys = [(e.get("association_id", ""), e.get("bl_number", "")) for e in estimate_data]
    if len(estimate_keys) != len(set(estimate_keys)):
        log("[WARNING] Duplicate estimate rows detected!", color='yellow')

    for i, inv in enumerate(invoice_data):
        best_result = None
        best_match_count = -1
        best_total = 0
        candidate_matches = []  # Track all matches for ambiguity check

        for j, est in enumerate(estimate_data):
            row_result = {
                "invoice_row": i + 1,
                "estimate_row": j + 1,
                "matches": [],
                "match_count": 0,
                "total": 0
            }

            # Check ASSOCIATION_ID
            inv_assoc = inv.get("association_id", "").strip()
            est_assoc = est.get("association_id", "").strip()
            if inv_assoc != est_assoc:
                log(f"[SKIPPED] Association ID mismatch. Invoice='{inv_assoc}' | Estimate='{est_assoc}'",
                    color='orange')
                row_result["matches"].append(
                    {"key": "association_id", "invoice": inv_assoc, "estimate": est_assoc, "match": False,
                     "skipped": True})
                all_comparisons.append(row_result)
                continue
            else:
                row_result["matches"].append(
                    {"key": "association_id", "invoice": inv_assoc, "estimate": est_assoc, "match": True})
                row_result["total"] += 1
                row_result["match_count"] += 1

            # Primary key check
            bl_match_found = False
            for key in primary_keys:
                if key == "bl_match":
                    bl_match = False
                    inv_bl_val = ""
                    est_bl_val = ""
                    inv_source = ""
                    est_source = ""
                    for inv_key in invoice_bl_keys:
                        for est_key in estimate_bl_keys:
                            inv_bl = inv.get(inv_key, "").strip()
                            est_bl = est.get(est_key, "").strip()
                            if clean_bl(inv_bl) and clean_bl(est_bl) and clean_bl(inv_bl) == clean_bl(est_bl):
                                bl_match = True
                                inv_bl_val = inv_bl
                                est_bl_val = est_bl
                                inv_source = inv_key
                                est_source = est_key
                                bl_match_found = True
                                break
                        if bl_match:
                            break

                    if not inv_bl_val:
                        inv_bl_val = next((inv.get(k, "") for k in invoice_bl_keys if inv.get(k)), "")
                        inv_source = next((k for k in invoice_bl_keys if inv.get(k)), "")
                    if not est_bl_val:
                        est_bl_val = next((est.get(k, "") for k in estimate_bl_keys if est.get(k)), "")
                        est_source = next((k for k in estimate_bl_keys if est.get(k)), "")

                    row_result["matches"].append({
                        "key": "bl_match",
                        "invoice": inv_bl_val,
                        "estimate": est_bl_val,
                        "match": bl_match,
                        "invoice_source": inv_source,
                        "estimate_source": est_source
                    })
                    if bl_match:
                        row_result["total"] += 1
                        row_result["match_count"] += 1
                    else:
                        row_result["total"] += 1
                    if not bl_match:
                        log(f"[SKIPPED] BL Match failed. Invoice({inv_source})='{inv_bl_val}' | Estimate({est_source})='{est_bl_val}'",
                            color='red')
                else:
                    inv_val = inv.get(key, "").strip()
                    est_val = est.get(key, "").strip()
                    match = inv_val == est_val

                    if inv_val in ['0', '']:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": False, "skipped": True})
                    else:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                    if not match and key != "sequence_number":
                        log(f"[SKIPPED] Primary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                            color='red')

            # Secondary key check
            if bl_match_found:
                for key in secondary_keys:
                    inv_val = inv.get(key, "").strip()
                    est_key = key_map[key]
                    est_val = est.get(est_key, "").strip()

                    if inv_val in ['0', '']:
                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": False, "skipped": True})
                    else:
                        if key == "line_amount":
                            currency = inv.get("currency", "").strip().upper()
                            est_val = est_val if currency == "GBP" else est.get("line_amount(quantity*expprice)",
                                                                                "").strip()
                            match = is_within_tolerance(inv_val, est_val)
                        else:
                            match = inv_val == est_val

                        row_result["matches"].append(
                            {"key": key, "invoice": inv_val, "estimate": est_val, "match": match})
                        row_result["total"] += 1
                        if match:
                            row_result["match_count"] += 1
                    if not match and key != "line_amount":
                        log(f"[SKIPPED] Secondary parameter mismatch on '{key}'. Invoice='{inv_val}' | Estimate='{est_val}'",
                            color='red')

            all_comparisons.append(row_result)
            candidate_matches.append(row_result)  # Collect for ambiguity check

            if row_result["match_count"] > best_match_count:
                best_result = row_result
                best_match_count = row_result["match_count"]
                best_total = row_result["total"]

        # Check for ambiguous matches
        close_matches = [m for m in candidate_matches if m["match_count"] >= best_match_count - 1 and m != best_result]
        if close_matches and best_result:
            log(f"[WARNING] Ambiguous matches for Invoice Row {i + 1}: {len(close_matches)} close candidates", color='yellow')
            ambiguous_matches = [best_result] + close_matches
            log_comparison_result(ambiguous_matches, best_only=True, section_title="[ AMBIGUOUS MATCHES ]")
            BuiltIn().fail(f"Ambiguous matches detected for Invoice Row {i + 1}")

        if best_result and best_match_count > 0:
            expected_status = "Matched" if best_match_count == best_total else "Estimates Mismatch"
            actual_status = inv.get("finato_matching_status", "").strip()
            best_result["expected_status"] = expected_status
            best_result["actual_status"] = actual_status
            best_result["finato_validated"] = (expected_status == actual_status)
            best_matches.append(best_result)
            top_matches_dict[(best_result["invoice_row"], best_result["estimate_row"])] = best_result
        else:
            log(f"[SKIPPED] No valid match found for Invoice Row {i + 1}", color='orange')
            best_matches.append({
                "invoice_row": i + 1,
                "estimate_row": "-",
                "matches": [],
                "match_count": 0,
                "total": 0,
                "expected_status": "Estimates Mismatch",
                "actual_status": inv.get("finato_matching_status", "").strip(),
                "finato_validated": False
            })

    # Dynamic TOP MATCHES
    top_matches = [m for m in best_matches if m["estimate_row"] != "-"]

    # Check for currency mismatches
    currency_mismatches = [m for m in top_matches if any(match["key"] == "currency" and not match["match"] for match in m["matches"])]
    if currency_mismatches:
        log_comparison_result(currency_mismatches, best_only=True, section_title="[ CURRENCY MISMATCHES ]")
        BuiltIn().fail("Currency mismatches detected!")

    # Aggregation Filter
    aggregation_groups = {}
    invalid_matches = [m for m in best_matches if not m.get("finato_validated", True) and m["estimate_row"] != "-"]
    if invalid_matches:
        for result in invalid_matches:
            if result["match_count"] == result["total"] - 1:  # Only line_amount mismatched
                inv_row = result["invoice_row"]
                est_row = result["estimate_row"]
                assoc_id = next(m["invoice"] for m in result["matches"] if m["key"] == "association_id")
                bl_val = next(m["invoice"] for m in result["matches"] if m["key"] == "bl_match")
                currency = next(m["invoice"] for m in result["matches"] if m["key"] == "currency")
                key = (est_row, assoc_id, bl_val, currency)
                if key not in aggregation_groups:
                    aggregation_groups[key] = {
                        "invoice_rows": [],
                        "estimate_row": est_row,
                        "line_amounts": [],
                        "matches": copy.deepcopy(result["matches"]),
                        "total": result["total"],
                        "match_count": result["match_count"],
                        "actual_status": result["actual_status"]
                    }
                aggregation_groups[key]["invoice_rows"].append(inv_row)
                line_amount = next(m["invoice"] for m in result["matches"] if m["key"] == "line_amount")
                aggregation_groups[key]["line_amounts"].append(line_amount)

    # Process Aggregated Matches
    aggregated_matches = []
    aggregated_invoice_rows = set()
    for key, group in aggregation_groups.items():
        if len(group["invoice_rows"]) > 1:  # Only aggregate multiple rows
            est_row = group["estimate_row"]
            summed_amount = sum(float(amt.replace(',', '')) for amt in group["line_amounts"])
            est_line_amount = next(m["estimate"] for m in group["matches"] if m["key"] == "line_amount")
            line_amount_match = is_within_tolerance(summed_amount, est_line_amount)

            for match in group["matches"]:
                if match["key"] == "line_amount":
                    match["invoice"] = str(summed_amount)
                    match["match"] = line_amount_match
                    match["msg"] = " | Aggregated"

            aggregated_result = {
                "invoice_row": ",".join(str(r) for r in sorted(group["invoice_rows"])),
                "estimate_row": est_row,
                "matches": group["matches"],
                "match_count": group["match_count"] + 1 if line_amount_match else group["match_count"],
                "total": group["total"],
                "is_aggregated": True,
                "expected_status": "Matched" if line_amount_match else "Estimates Mismatch",
                "actual_status": group["actual_status"],
                "finato_validated": line_amount_match and group["actual_status"] == "Matched"
            }
            aggregated_matches.append(aggregated_result)
            aggregated_invoice_rows.update(group["invoice_rows"])

            inv_rows_str = ", ".join(str(r) for r in sorted(group["invoice_rows"]))
            log(f"[DEBUG] Aggregation required between [COMPARING ROW {inv_rows_str} :: ESTIMATE ROW {est_row}]",
                color='blue')

    # Dynamic FILTERED TOP MATCHES
    filtered_top_matches = [
        m for m in top_matches if m["finato_validated"] and m["invoice_row"] not in aggregated_invoice_rows
    ]
    if aggregated_matches:
        filtered_top_matches.extend(aggregated_matches)

    # Check for unmatched rows
    invoice_rows_covered = set()
    for m in filtered_top_matches:
        if m.get("is_aggregated", False):
            invoice_rows_covered.update(map(int, m["invoice_row"].split(",")))
        else:
            invoice_rows_covered.add(m["invoice_row"])
    unmatched_rows = [m for m in top_matches if m["invoice_row"] not in invoice_rows_covered]
    if unmatched_rows:
        log_comparison_result(unmatched_rows, best_only=True, section_title="[ UNMATCHED ROWS ]")

    # Log suspect matches (high score but invalid)
    suspect_matches = [m for m in top_matches if m["match_count"] >= m["total"] - 1 and not m["finato_validated"] and m["invoice_row"] not in aggregated_invoice_rows]
    if suspect_matches:
        log_comparison_result(suspect_matches, best_only=True, section_title="[ SUSPECT MATCHES ]")

    # Log sections
    log_comparison_result(top_matches, best_only=True, section_title="[ TOP MATCHES ]")
    if aggregated_matches:
        log_comparison_result(aggregated_matches, best_only=True, section_title="[ AGGREGATED COMPARISONS ]")
    log_comparison_result(filtered_top_matches, best_only=True, section_title="[ FINAL RESULTS ]")

    # Comprehensive validation
    all_valid = all(r.get("finato_validated", True) for r in filtered_top_matches)
    if unmatched_rows or suspect_matches or not all_valid:
        BuiltIn().fail(f"Validation failed: {len(unmatched_rows)} unmatched rows, {len(suspect_matches)} suspect matches, {sum(1 for r in filtered_top_matches if not r.get('finato_validated', True))} invalid matches!")

    # Summary report
    log(f"[SUMMARY] Processed {len(invoice_data)} invoice rows: {len(filtered_top_matches)} valid matches, {len(aggregated_matches)} aggregated, {len(unmatched_rows)} unmatched, {len(suspect_matches)} suspect", color='green')

    return filtered_top_matches, all_comparisons